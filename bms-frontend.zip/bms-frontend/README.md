# bms-frontend

Angular 18 SPA for the **Glory Building · Building Management System** (ASP.NET Core + MSSQL backend).
Visual style follows the Figma board: white cards on a slate background, navy pill navigation, blue accent,
ETB currency, and a colour-coded floor-plan grid.

## Run it

```bash
npm install
npm start          # http://localhost:4200
```

By default `src/environments/environment.ts` has `useMock: true`, so an **in-memory mock API** answers every
`/api/*` call. You can click through the whole app before the ASP.NET API exists.

### Demo logins (mock mode)

| Role    | Email             | Password     | Can do                    |
|---------|-------------------|--------------|---------------------------|
| Admin   | admin@glory.et    | Admin@123    | everything                |
| Manager | manager@glory.et  | Manager@123  | read / write              |
| Viewer  | viewer@glory.et   | Viewer@123   | read-only (buttons hidden)|

### Connect the real API

```ts
// src/environments/environment.ts
export const environment = { production: false, apiUrl: 'https://localhost:5001/api', useMock: false };
```

Enable CORS for `http://localhost:4200` in BMS.API.

## Structure

```
src/app
├── core
│   ├── models/         DTO interfaces + enums (mirror the API DTOs)
│   ├── services/       ApiService, AuthService, one service per feature, toast + loading state
│   ├── interceptors/   authInterceptor (Bearer JWT), errorInterceptor (401/403/5xx), loadingInterceptor
│   ├── guards/         authGuard, guestGuard, roleGuard
│   └── mock/           in-memory backend used when useMock = true
├── shared/             modal, pagination, chip, field-error, toasts, icons, SVG charts
├── layout/             shell: sidebar, header, notification bell (unread badge + dropdown)
└── features            auth · dashboard · units · tenants · leases · payments · reports · notifications
```

Standalone components, lazy-loaded routes, signals, Reactive Forms with inline validation. No UI or chart
library: charts are small SVG components so there is nothing extra to install.

## Assignment checklist

- JWT storage, auth guard, Bearer interceptor: `core/`
- Error interceptor: 401 → login, 403 → message, 5xx / network → toast
- Server-side pagination on every list (units, tenants, leases, payments)
- Reactive forms with inline validation; submit buttons disabled and show a spinner while saving
- Global progress bar plus per-table spinners during HTTP calls
- Dashboard KPI cards + revenue and occupancy charts
- Units floor-plan grid with unit + floor info panels
- Reports: selector, filter panel, results table, charts, Excel export
- Notifications: bell with unread badge, dropdown, mark-all-read, full page

## API contract the frontend expects

Responses may be raw or wrapped as `{ success, data, message }` (the wrapper is unwrapped automatically).
Lists return `{ items, totalCount, page, pageSize }`. Send `page` and `pageSize` query params.
JSON is camelCase (ASP.NET default). All paths are under `/api`.

| Call | Notes |
|------|-------|
| `POST auth/login` | → `{ token, refreshToken, expiresAt, user: { id, fullName, email, role } }` |
| `GET units` | filters: `search, floor, status, unitType` |
| `GET units/floors` | → per-floor `{ floorNumber, totalUnits, occupied, available, underMaintenance, reserved, units[] }` |
| `POST units`, `PUT units/{id}`, `PUT units/{id}/status` `{status}`, `DELETE units/{id}` | 409 when the unit has any lease |
| `GET tenants` | filters: `search` (name / TIN / business type), `businessType`, `isActive` |
| `GET tenants/{id}` | includes `documents[]` and `activeUnits[]` |
| `POST tenants`, `PUT tenants/{id}`, `PUT tenants/{id}/deactivate` | |
| `POST tenants/{id}/documents` | multipart: `file`, `documentType`, `expiryDate` |
| `GET leases` | filters: `status, tenantId, unitId` (lease history) |
| `POST leases`, `PUT leases/{id}/renew` `{newEndDate,newMonthlyRent}`, `PUT leases/{id}/terminate` `{reason}` | |
| `GET payments`, `GET payments/outstanding`, `POST payments` | outstanding returns invoices with `amountPaid` and `balance` |
| `POST invoices/generate` | → `{ generated }` |
| `GET reports/{occupancy\|revenue\|arrears\|lease-expiry\|document-expiry}` | → `{ rows[], summary: [{label,value}] }`; params `year`, `days` |
| `GET reports/export/{type}` | returns the .xlsx file |
| `GET notifications`, `PUT notifications/{id}/read`, `PUT notifications/read-all` | |
| `GET dashboard` | → `{ occupancyPercent, totalRevenue, outstanding, vacantUnits, totalUnits, revenueByMonth[], occupancyByFloor[] }` |

Report row field names are defined in `features/reports/reports-page.component.ts` (the `DEFS` array).
