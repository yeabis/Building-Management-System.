import { HttpErrorResponse, HttpInterceptorFn, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, delay, of, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  DbInvoice, DbLease, DbTenant, DbUnit, NOW, createInvoice, db, paidOn, refreshInvoiceStatuses, users,
} from './mock-db';

/**
 * Stand-in for BMS.API. Enabled by environment.useMock. It sits LAST in the interceptor chain so the real
 * auth / error / loading interceptors behave exactly as they will against the live API.
 */

class MockError { constructor(public status: number, public message: string) {} }
const iso = (d: Date) => d.toISOString().slice(0, 10);

// ---------- DTO mappers (entities never leave the "server") ----------
const activeLeaseOfUnit = (unitId: number) => db.leases.find((l) => l.unitId === unitId && l.status === 'Active' && !l.isDeleted);
const tenantById = (id: number) => db.tenants.find((t) => t.id === id)!;
const unitById = (id: number) => db.units.find((u) => u.id === id)!;

const unitDto = (u: DbUnit) => {
  const l = activeLeaseOfUnit(u.id);
  const { isDeleted, ...rest } = u;
  return { ...rest, tenantName: l ? tenantById(l.tenantId).organizationName : null };
};
const tenantDto = (t: DbTenant, withDocs = false) => {
  const { isDeleted, ...rest } = t;
  const activeUnits = db.leases.filter((l) => l.tenantId === t.id && l.status === 'Active' && !l.isDeleted).map((l) => unitById(l.unitId).unitNumber);
  return { ...rest, activeUnits, ...(withDocs ? { documents: db.docs.filter((d) => d.tenantId === t.id) } : {}) };
};
const leaseDto = (l: DbLease) => {
  const { isDeleted, ...rest } = l;
  return { ...rest, unitNumber: unitById(l.unitId).unitNumber, tenantName: tenantById(l.tenantId).organizationName };
};
const invoiceDto = (i: DbInvoice) => {
  const l = db.leases.find((x) => x.id === i.leaseId)!;
  const paid = paidOn(i.id);
  return { ...i, tenantName: tenantById(l.tenantId).organizationName, unitNumber: unitById(l.unitId).unitNumber, amountPaid: paid, balance: Math.max(0, i.amountDue - paid) };
};
const paymentDto = (p: (typeof db.payments)[number]) => {
  const inv = db.invoices.find((i) => i.id === p.invoiceId)!;
  const l = db.leases.find((x) => x.id === inv.leaseId)!;
  return { ...p, invoiceNumber: inv.invoiceNumber, tenantName: tenantById(l.tenantId).organizationName };
};

function paged<T>(list: T[], q: URLSearchParams) {
  const page = Math.max(1, Number(q.get('page') ?? 1));
  const pageSize = Math.max(1, Number(q.get('pageSize') ?? 10));
  return { items: list.slice((page - 1) * pageSize, page * pageSize), totalCount: list.length, page, pageSize };
}
const has = (s: string, term: string) => s.toLowerCase().includes(term.toLowerCase());
const daysFromNow = (d: string) => Math.ceil((new Date(d).getTime() - NOW.getTime()) / 86400000);
const money = (n: number) => Math.round(n);

// ---------- Reports ----------
function occupancyRows() {
  const live = db.units.filter((u) => !u.isDeleted);
  return [1, 2, 3, 4, 5, 6, 7].map((f) => {
    const us = live.filter((u) => u.floorNumber === f);
    const occupied = us.filter((u) => u.status === 'Occupied').length;
    return { floor: `Floor ${f}`, totalUnits: us.length, occupied, vacant: us.length - occupied, occupancyPercent: us.length ? Math.round((occupied / us.length) * 100) : 0 };
  });
}
function revenueRows(year: number) {
  return Array.from({ length: 12 }, (_, i) => i + 1)
    .filter((m) => year < NOW.getFullYear() || m <= NOW.getMonth() + 1)
    .map((m) => {
      const invs = db.invoices.filter((i) => i.periodYear === year && i.periodMonth === m && i.status !== 'Cancelled');
      const expected = invs.reduce((s, i) => s + i.amountDue, 0);
      const collected = invs.reduce((s, i) => s + paidOn(i.id), 0);
      return { month: new Date(year, m - 1, 1).toLocaleString('en', { month: 'short' }), expected, collected, collectionRate: expected ? Math.round((collected / expected) * 100) : 0 };
    })
    .filter((r) => r.expected > 0);
}
function arrearsRows() {
  const byLease = new Map<number, { months: number; owed: number }>();
  db.invoices.filter((i) => i.status === 'Overdue').forEach((i) => {
    const bal = i.amountDue - paidOn(i.id);
    const cur = byLease.get(i.leaseId) ?? { months: 0, owed: 0 };
    byLease.set(i.leaseId, { months: cur.months + 1, owed: cur.owed + bal });
  });
  return [...byLease.entries()].map(([leaseId, v]) => {
    const l = db.leases.find((x) => x.id === leaseId)!;
    return { tenantName: tenantById(l.tenantId).organizationName, unitNumber: unitById(l.unitId).unitNumber, monthsOverdue: v.months, totalOwed: v.owed };
  }).sort((a, b) => b.totalOwed - a.totalOwed);
}
function leaseExpiryRows(days: number) {
  return db.leases.filter((l) => !l.isDeleted && l.status === 'Active' && daysFromNow(l.endDate) <= days && daysFromNow(l.endDate) >= 0)
    .map((l) => ({ ...leaseDto(l), daysRemaining: daysFromNow(l.endDate) })).sort((a, b) => a.daysRemaining - b.daysRemaining)
    .map((l) => ({ tenantName: l.tenantName, unitNumber: l.unitNumber, endDate: l.endDate, monthlyRent: l.monthlyRent, daysRemaining: l.daysRemaining }));
}
function documentExpiryRows() {
  return db.docs.filter((d) => d.expiryDate && daysFromNow(d.expiryDate) <= 30 && daysFromNow(d.expiryDate) >= 0)
    .map((d) => ({ tenantName: tenantById(d.tenantId).organizationName, documentType: d.documentType, expiryDate: d.expiryDate, daysRemaining: daysFromNow(d.expiryDate!) }))
    .sort((a, b) => a.daysRemaining - b.daysRemaining);
}
function report(type: string, q: URLSearchParams) {
  switch (type) {
    case 'occupancy': {
      const rows = occupancyRows();
      const total = rows.reduce((s, r) => s + r.totalUnits, 0);
      const occ = rows.reduce((s, r) => s + r.occupied, 0);
      return { rows, summary: [{ label: 'Total units', value: total }, { label: 'Occupied', value: occ }, { label: 'Vacant', value: total - occ }, { label: 'Occupancy', value: `${total ? Math.round((occ / total) * 100) : 0}%` }] };
    }
    case 'revenue': {
      const rows = revenueRows(Number(q.get('year') ?? NOW.getFullYear()));
      const exp = rows.reduce((s, r) => s + r.expected, 0);
      const col = rows.reduce((s, r) => s + r.collected, 0);
      return { rows, summary: [{ label: 'Expected (YTD)', value: money(exp) }, { label: 'Collected (YTD)', value: money(col) }, { label: 'Collection rate', value: `${exp ? Math.round((col / exp) * 100) : 0}%` }] };
    }
    case 'arrears': {
      const rows = arrearsRows();
      return { rows, summary: [{ label: 'Tenants in arrears', value: rows.length }, { label: 'Total owed', value: money(rows.reduce((s, r) => s + r.totalOwed, 0)) }] };
    }
    case 'lease-expiry': {
      const rows = leaseExpiryRows(Number(q.get('days') ?? 30));
      return { rows, summary: [{ label: 'Leases expiring', value: rows.length }] };
    }
    case 'document-expiry': {
      const rows = documentExpiryRows();
      return { rows, summary: [{ label: 'Documents expiring', value: rows.length }] };
    }
  }
  throw new MockError(404, 'Unknown report');
}
function toCsv(rows: Record<string, any>[]) {
  if (!rows.length) return '';
  const cols = Object.keys(rows[0]);
  return [cols.join(','), ...rows.map((r) => cols.map((c) => JSON.stringify(r[c] ?? '')).join(','))].join('\n');
}

// ---------- Routes ----------
type Ctx = { m: RegExpMatchArray; q: URLSearchParams; body: any };
const routes: [string, RegExp, (c: Ctx) => any][] = [
  ['POST', /^auth\/login$/, ({ body }) => {
    const u = users.find((x) => x.email.toLowerCase() === String(body.email).toLowerCase() && x.password === body.password);
    if (!u) throw new MockError(401, 'Invalid email or password.');
    const { password, ...user } = u;
    return { token: `mock.${btoa(JSON.stringify(user))}.sig`, refreshToken: 'mock-refresh', expiresAt: new Date(Date.now() + 8 * 3600000).toISOString(), user };
  }],

  // Dashboard
  ['GET', /^dashboard$/, () => {
    const live = db.units.filter((u) => !u.isDeleted);
    const occ = live.filter((u) => u.status === 'Occupied').length;
    const rev = revenueRows(NOW.getFullYear());
    const outstanding = db.invoices.filter((i) => i.status === 'Overdue' || i.status === 'Issued').reduce((s, i) => s + (i.amountDue - paidOn(i.id)), 0);
    return {
      occupancyPercent: Math.round((occ / live.length) * 1000) / 10,
      totalRevenue: db.payments.reduce((s, p) => s + p.amountPaid, 0),
      outstanding, vacantUnits: live.filter((u) => u.status === 'Available').length, totalUnits: live.length,
      revenueByMonth: rev.slice(-6).map((r) => ({ month: r.month, expected: r.expected, collected: r.collected })),
      occupancyByFloor: occupancyRows().map((r, i) => ({ floor: i + 1, occupied: r.occupied, vacant: r.vacant })),
    };
  }],

  // Units
  ['GET', /^units\/floors$/, () => [1, 2, 3, 4, 5, 6, 7].map((f) => {
    const us = db.units.filter((u) => u.floorNumber === f && !u.isDeleted);
    const c = (s: string) => us.filter((u) => u.status === s).length;
    return { floorNumber: f, totalUnits: us.length, occupied: c('Occupied'), available: c('Available'), underMaintenance: c('UnderMaintenance'), reserved: c('Reserved'), units: us.map(unitDto) };
  })],
  ['GET', /^units$/, ({ q }) => {
    let l = db.units.filter((u) => !u.isDeleted);
    if (q.get('search')) l = l.filter((u) => has(u.unitNumber, q.get('search')!) || has(u.description, q.get('search')!));
    if (q.get('floor')) l = l.filter((u) => u.floorNumber === Number(q.get('floor')));
    if (q.get('status')) l = l.filter((u) => u.status === q.get('status'));
    if (q.get('unitType')) l = l.filter((u) => u.unitType === q.get('unitType'));
    const p = paged(l, q);
    return { ...p, items: p.items.map(unitDto) };
  }],
  ['POST', /^units$/, ({ body }) => {
    if (db.units.some((u) => !u.isDeleted && u.unitNumber === body.unitNumber)) throw new MockError(409, `Unit ${body.unitNumber} already exists.`);
    const u: DbUnit = { ...body, id: ++db.seq.unit, isDeleted: false };
    db.units.push(u);
    return unitDto(u);
  }],
  ['PUT', /^units\/(\d+)\/status$/, ({ m, body }) => {
    const u = unitById(+m[1]);
    if (activeLeaseOfUnit(u.id) && body.status !== 'Occupied') throw new MockError(409, 'Terminate the active lease before changing this unit status.');
    u.status = body.status;
    return unitDto(u);
  }],
  ['PUT', /^units\/(\d+)$/, ({ m, body }) => { const u = unitById(+m[1]); Object.assign(u, body); return unitDto(u); }],
  ['DELETE', /^units\/(\d+)$/, ({ m }) => {
    const u = unitById(+m[1]);
    if (db.leases.some((l) => l.unitId === u.id && !l.isDeleted)) throw new MockError(409, 'This unit has an active or historical lease and cannot be deleted.');
    u.isDeleted = true;
    return null;
  }],

  // Tenants
  ['GET', /^tenants$/, ({ q }) => {
    let l = db.tenants.filter((t) => !t.isDeleted);
    const s = q.get('search');
    if (s) l = l.filter((t) => has(t.organizationName, s) || has(t.tinNumber, s) || has(t.businessType, s));
    if (q.get('businessType')) l = l.filter((t) => t.businessType === q.get('businessType'));
    if (q.get('isActive')) l = l.filter((t) => String(t.isActive) === q.get('isActive'));
    const p = paged(l, q);
    return { ...p, items: p.items.map((t) => tenantDto(t)) };
  }],
  ['GET', /^tenants\/(\d+)$/, ({ m }) => tenantDto(tenantById(+m[1]), true)],
  ['POST', /^tenants\/(\d+)\/documents$/, ({ m, body }) => {
    const f = body as FormData;
    const file = f.get('file') as File | null;
    const d = { id: ++db.seq.doc, tenantId: +m[1], documentType: f.get('documentType') as any, fileName: file?.name ?? 'document.pdf', uploadedAt: iso(NOW), expiryDate: (f.get('expiryDate') as string) || null, isVerified: false };
    db.docs.push(d);
    return d;
  }],
  ['POST', /^tenants$/, ({ body }) => {
    if (db.tenants.some((t) => !t.isDeleted && t.tinNumber === body.tinNumber)) throw new MockError(409, 'A tenant with this TIN already exists.');
    const t: DbTenant = { ...body, id: ++db.seq.tenant, isActive: true, isDeleted: false };
    db.tenants.push(t);
    return tenantDto(t);
  }],
  ['PUT', /^tenants\/(\d+)\/deactivate$/, ({ m }) => {
    const t = tenantById(+m[1]);
    if (db.leases.some((l) => l.tenantId === t.id && l.status === 'Active')) throw new MockError(409, 'Terminate this tenant\'s active leases before deactivating.');
    t.isActive = false;
    return null;
  }],
  ['PUT', /^tenants\/(\d+)$/, ({ m, body }) => { const t = tenantById(+m[1]); Object.assign(t, body); return tenantDto(t); }],

  // Leases
  ['GET', /^leases$/, ({ q }) => {
    let l = db.leases.filter((x) => !x.isDeleted);
    if (q.get('status')) l = l.filter((x) => x.status === q.get('status'));
    if (q.get('tenantId')) l = l.filter((x) => x.tenantId === Number(q.get('tenantId')));
    if (q.get('unitId')) l = l.filter((x) => x.unitId === Number(q.get('unitId')));
    l = [...l].sort((a, b) => b.startDate.localeCompare(a.startDate));
    const p = paged(l, q);
    return { ...p, items: p.items.map(leaseDto) };
  }],
  ['POST', /^leases$/, ({ body }) => {
    const u = unitById(body.unitId);
    if (u.status !== 'Available' && u.status !== 'Reserved') throw new MockError(409, `Unit ${u.unitNumber} is not available for lease.`);
    if (new Date(body.endDate) <= new Date(body.startDate)) throw new MockError(400, 'End date must be after start date.');
    const l: DbLease = { ...body, id: ++db.seq.lease, status: 'Active', terminationReason: null, isDeleted: false };
    db.leases.push(l);
    u.status = 'Occupied';
    return leaseDto(l);
  }],
  ['PUT', /^leases\/(\d+)\/renew$/, ({ m, body }) => {
    const l = db.leases.find((x) => x.id === +m[1])!;
    if (new Date(body.newEndDate) <= new Date(l.endDate)) throw new MockError(400, 'New end date must be after the current end date.');
    l.endDate = body.newEndDate; l.monthlyRent = body.newMonthlyRent; l.status = 'Active';
    return leaseDto(l);
  }],
  ['PUT', /^leases\/(\d+)\/terminate$/, ({ m, body }) => {
    const l = db.leases.find((x) => x.id === +m[1])!;
    l.status = 'Terminated'; l.terminationReason = body.reason;
    unitById(l.unitId).status = 'Available';
    return leaseDto(l);
  }],

  // Payments & invoices
  ['GET', /^payments\/outstanding$/, ({ q }) => {
    refreshInvoiceStatuses();
    const l = db.invoices.filter((i) => i.status === 'Overdue' || i.status === 'Issued').map(invoiceDto).filter((i) => i.balance > 0)
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
    return paged(l, q);
  }],
  ['GET', /^payments$/, ({ q }) => paged([...db.payments].sort((a, b) => b.paymentDate.localeCompare(a.paymentDate) || b.id - a.id).map(paymentDto), q)],
  ['POST', /^payments$/, ({ body }) => {
    const inv = db.invoices.find((i) => i.id === body.invoiceId);
    if (!inv) throw new MockError(404, 'Invoice not found.');
    const balance = inv.amountDue - paidOn(inv.id);
    if (body.amountPaid <= 0) throw new MockError(400, 'Amount must be greater than zero.');
    if (body.amountPaid > balance) throw new MockError(400, `Amount exceeds the outstanding balance of ETB ${balance.toLocaleString()}.`);
    const p = { ...body, id: ++db.seq.payment };
    db.payments.push(p);
    refreshInvoiceStatuses();
    return paymentDto(p);
  }],
  ['POST', /^invoices\/generate$/, () => {
    const y = NOW.getFullYear(), mo = NOW.getMonth() + 1;
    let generated = 0;
    db.leases.filter((l) => l.status === 'Active' && !l.isDeleted).forEach((l) => {
      if (!db.invoices.some((i) => i.leaseId === l.id && i.periodYear === y && i.periodMonth === mo)) { createInvoice(l, y, mo); generated++; }
    });
    return { generated };
  }],

  // Reports
  ['GET', /^reports\/export\/([\w-]+)$/, ({ m, q }) => ({ __blob: toCsv(report(m[1], q).rows) })],
  ['GET', /^reports\/([\w-]+)$/, ({ m, q }) => report(m[1], q)],

  // Notifications
  ['PUT', /^notifications\/read-all$/, () => { db.notifications.forEach((n) => (n.isRead = true)); return null; }],
  ['PUT', /^notifications\/(\d+)\/read$/, ({ m }) => { const n = db.notifications.find((x) => x.id === +m[1]); if (n) n.isRead = true; return null; }],
  ['GET', /^notifications$/, ({ q }) => paged([...db.notifications].sort((a, b) => b.createdAt.localeCompare(a.createdAt)), q)],
];

function handle(req: HttpRequest<unknown>): Observable<any> {
  const url = new URL(req.urlWithParams);
  const path = url.pathname.replace(/^.*\/api\//, '');
  const route = routes.find(([method, rx]) => method === req.method && rx.test(path));
  if (!route) return throwError(() => new HttpErrorResponse({ status: 404, error: { message: `Mock: no route for ${req.method} ${path}` } }));

  // Everything except login needs a token, and Viewers may not write.
  if (!path.startsWith('auth/')) {
    const auth = req.headers.get('Authorization');
    if (!auth) return throwError(() => new HttpErrorResponse({ status: 401, error: { message: 'Unauthorized' } }));
    try {
      const user = JSON.parse(atob(auth.split('.')[1]));
      if (req.method !== 'GET' && user.role === 'Viewer') return throwError(() => new HttpErrorResponse({ status: 403, error: { message: 'Forbidden' } }));
    } catch { return throwError(() => new HttpErrorResponse({ status: 401, error: { message: 'Invalid token' } })); }
  }

  try {
    const out = route[2]({ m: path.match(route[1])!, q: url.searchParams, body: req.body });
    if (out && out.__blob !== undefined) {
      return of(new HttpResponse({ status: 200, body: new Blob([out.__blob], { type: 'text/csv' }) }));
    }
    return of(new HttpResponse({ status: 200, body: { success: true, data: out } }));
  } catch (e) {
    if (e instanceof MockError) return throwError(() => new HttpErrorResponse({ status: e.status, error: { success: false, message: e.message } }));
    throw e;
  }
}

export const mockApiInterceptor: HttpInterceptorFn = (req, next) => {
  if (!environment.useMock || !req.url.startsWith(environment.apiUrl)) return next(req);
  return handle(req).pipe(delay(280));
};
