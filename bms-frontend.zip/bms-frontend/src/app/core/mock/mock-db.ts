/* In-memory seed data used when environment.useMock = true. Mirrors the shapes the ASP.NET API should return. */
import { BusinessType, DocumentType, InvoiceStatus, UnitStatus } from '../models/models';

const iso = (d: Date) => d.toISOString().slice(0, 10);
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const addMonths = (d: Date, n: number) => { const x = new Date(d); x.setMonth(x.getMonth() + n); return x; };

export const NOW = new Date();

export interface DbUnit { id: number; floorNumber: number; unitNumber: string; unitType: 'Shop' | 'Office'; areaSqMeters: number; monthlyRent: number; status: UnitStatus; description: string; isDeleted: boolean }
export interface DbTenant { id: number; organizationName: string; tinNumber: string; phone: string; businessType: BusinessType; contactPersonName: string; contactEmail: string; isActive: boolean; isDeleted: boolean }
export interface DbDoc { id: number; tenantId: number; documentType: DocumentType; fileName: string; uploadedAt: string; expiryDate: string | null; isVerified: boolean }
export interface DbLease { id: number; unitId: number; tenantId: number; startDate: string; endDate: string; monthlyRent: number; depositAmount: number; status: 'Active' | 'Expired' | 'Terminated' | 'PendingRenewal'; terminationReason: string | null; isDeleted: boolean }
export interface DbInvoice { id: number; leaseId: number; invoiceNumber: string; amountDue: number; dueDate: string; issueDate: string; status: InvoiceStatus; periodMonth: number; periodYear: number }
export interface DbPayment { id: number; invoiceId: number; amountPaid: number; paymentDate: string; paymentMethod: string; referenceNumber: string; notes: string | null }
export interface DbNotification { id: number; title: string; message: string; notificationType: string; isRead: boolean; createdAt: string }

export const db = {
  seq: { unit: 0, tenant: 0, doc: 0, lease: 0, invoice: 0, payment: 0, notification: 0 },
  units: [] as DbUnit[],
  tenants: [] as DbTenant[],
  docs: [] as DbDoc[],
  leases: [] as DbLease[],
  invoices: [] as DbInvoice[],
  payments: [] as DbPayment[],
  notifications: [] as DbNotification[],
};

export const users = [
  { id: 'u1', fullName: 'Abenezer Yohannes', email: 'admin@glory.et', password: 'Admin@123', role: 'Admin' as const },
  { id: 'u2', fullName: 'Meron Tadesse', email: 'manager@glory.et', password: 'Manager@123', role: 'Manager' as const },
  { id: 'u3', fullName: 'Dawit Bekele', email: 'viewer@glory.et', password: 'Viewer@123', role: 'Viewer' as const },
];

export function invoiceNumber(year: number, month: number, leaseId: number) {
  return `INV-${year}${String(month).padStart(2, '0')}-${String(leaseId).padStart(4, '0')}`;
}

export function paidOn(invoiceId: number) {
  return db.payments.filter((p) => p.invoiceId === invoiceId).reduce((s, p) => s + p.amountPaid, 0);
}

/** Flip Issued -> Overdue / Paid based on payments and today's date. */
export function refreshInvoiceStatuses() {
  const t = iso(NOW);
  for (const inv of db.invoices) {
    if (inv.status === 'Cancelled' || inv.status === 'Draft') continue;
    const paid = paidOn(inv.id);
    if (paid >= inv.amountDue) inv.status = 'Paid';
    else inv.status = inv.dueDate < t ? 'Overdue' : 'Issued';
  }
}

function pay(inv: DbInvoice, amount: number, date: string, method: string) {
  db.payments.push({
    id: ++db.seq.payment, invoiceId: inv.id, amountPaid: amount, paymentDate: date,
    paymentMethod: method, referenceNumber: `TB-${inv.periodYear}${String(inv.id).padStart(5, '0')}`, notes: null,
  });
}

export function createInvoice(lease: DbLease, year: number, month: number): DbInvoice {
  const inv: DbInvoice = {
    id: ++db.seq.invoice, leaseId: lease.id, invoiceNumber: invoiceNumber(year, month, lease.id),
    amountDue: lease.monthlyRent, issueDate: iso(new Date(year, month - 1, 1)),
    dueDate: iso(new Date(year, month - 1, 5)), status: 'Issued', periodMonth: month, periodYear: year,
  };
  db.invoices.push(inv);
  return inv;
}

(function seed() {
  // ----- Units: 7 floors x 6 units -----
  for (let f = 1; f <= 7; f++) {
    for (let i = 1; i <= 6; i++) {
      const area = 38 + i * 11 + f * 4;
      const maintenance = (f === 1 && i >= 5) || (f === 4 && i === 2);
      const reserved = f === 6 && i === 6;
      const occupiedSlot = (f + i) % 3 !== 0;
      const status: UnitStatus = maintenance ? 'UnderMaintenance' : reserved ? 'Reserved' : occupiedSlot ? 'Occupied' : 'Available';
      db.units.push({
        id: ++db.seq.unit, floorNumber: f, unitNumber: `L${f}0${i}`,
        unitType: f <= 2 && i <= 3 ? 'Shop' : 'Office', areaSqMeters: area,
        monthlyRent: Math.round((area * (850 + f * 70)) / 100) * 100,
        status, isDeleted: false,
        description: f <= 2 && i <= 3 ? 'Street-facing retail space' : 'Open-plan office with natural light',
      });
    }
  }

  // ----- Tenants -----
  const tenantSeed: [string, BusinessType, string, string][] = [
    ['Vanguard Media Group', 'Services', 'Elena Rostova', 'info@vanguardmedia.et'],
    ['Apex Architecture Studio', 'Services', 'Samuel Girma', 'hello@apexarch.et'],
    ['Helios Energy Corp', 'Office', 'Kidist Alemu', 'office@heliosenergy.et'],
    ['Sunrise Pharmacy', 'Healthcare', 'Dr. Hanna Worku', 'sunrise@pharmacy.et'],
    ['Habesha Coffee House', 'Restaurant', 'Biruk Hailu', 'biruk@habeshacoffee.et'],
    ['Nexus Tech Labs', 'Services', 'Liya Tesfaye', 'contact@nexustech.et'],
    ['Blue Nile Bookstore', 'Retail', 'Yonas Desta', 'shop@bluenile.et'],
    ['Zenith Kids Academy', 'Education', 'Selam Mekonnen', 'admin@zenithkids.et'],
    ['Urban Retail Flagship', 'Retail', 'Tigist Abebe', 'urban@retail.et'],
    ['Meskel Law Partners', 'Services', 'Henok Assefa', 'office@meskellaw.et'],
  ];
  tenantSeed.forEach(([name, bt, contact, email], i) => {
    db.tenants.push({
      id: ++db.seq.tenant, organizationName: name, tinNumber: String(1000000001 + i * 7919), phone: `+2519${10000000 + i * 137}`,
      businessType: bt, contactPersonName: contact, contactEmail: email, isActive: true, isDeleted: false,
    });
  });

  // ----- Documents (some expiring soon) -----
  const docTypes: DocumentType[] = ['BusinessLicense', 'TradeLicense', 'TaxClearance'];
  db.tenants.forEach((t, i) => {
    docTypes.forEach((dt, j) => {
      const expiring = (i + j) % 4 === 0;
      db.docs.push({
        id: ++db.seq.doc, tenantId: t.id, documentType: dt, fileName: `${t.organizationName.split(' ')[0]}_${dt}.pdf`,
        uploadedAt: iso(addMonths(NOW, -8 - j)),
        expiryDate: iso(expiring ? addDays(NOW, 6 + i * 3) : addMonths(NOW, 5 + j * 3)),
        isVerified: (i + j) % 5 !== 0,
      });
    });
  });

  // ----- Leases for occupied units -----
  db.units.filter((u) => u.status === 'Occupied').forEach((u, idx) => {
    const monthsAgo = (idx % 9) + 1;
    const start = addMonths(NOW, -monthsAgo);
    const expiringSoon = idx % 6 === 0;
    const end = expiringSoon ? addDays(NOW, 8 + (idx % 20)) : addMonths(start, 12);
    db.leases.push({
      id: ++db.seq.lease, unitId: u.id, tenantId: db.tenants[idx % db.tenants.length].id,
      startDate: iso(start), endDate: iso(end), monthlyRent: u.monthlyRent, depositAmount: u.monthlyRent * 3,
      status: 'Active', terminationReason: null, isDeleted: false,
    });
  });

  // ----- Invoices + payments for last 6 months -----
  db.leases.forEach((l, idx) => {
    const leaseStart = new Date(l.startDate);
    for (let back = 5; back >= 0; back--) {
      const d = addMonths(new Date(NOW.getFullYear(), NOW.getMonth(), 1), -back);
      if (d < new Date(leaseStart.getFullYear(), leaseStart.getMonth(), 1)) continue;
      const inv = createInvoice(l, d.getFullYear(), d.getMonth() + 1);
      const due = new Date(inv.dueDate);
      if (back >= 2) pay(inv, inv.amountDue, iso(addDays(due, -(idx % 4))), 'BankTransfer');
      else if (back === 1) {
        if (idx % 4 !== 0) pay(inv, inv.amountDue, iso(addDays(due, idx % 3)), idx % 2 ? 'MobileMoney' : 'BankTransfer');
        else if (idx % 8 === 0) pay(inv, Math.round(inv.amountDue / 2), iso(addDays(due, 2)), 'Cash');
      } else if (idx % 5 === 0) pay(inv, inv.amountDue, iso(NOW), 'MobileMoney');
    }
  });
  refreshInvoiceStatuses();

  // ----- Notifications -----
  const n = (title: string, message: string, type: string, hoursAgo: number, read = false) =>
    db.notifications.push({ id: ++db.seq.notification, title, message, notificationType: type, isRead: read, createdAt: new Date(NOW.getTime() - hoursAgo * 3600000).toISOString() });
  n('Payment overdue', 'Invoices for 4 tenants are past their due date.', 'PaymentOverdue', 2);
  n('Lease expiring in 7 days', `Lease for unit ${db.units[db.leases[0].unitId - 1].unitNumber} ends soon.`, 'LeaseExpiry', 6);
  n('Document expiring', 'A Business License expires within 30 days.', 'DocumentExpiry', 20);
  n('Invoices generated', `Monthly invoices were generated for ${db.leases.length} active leases.`, 'General', 48, true);
})();
