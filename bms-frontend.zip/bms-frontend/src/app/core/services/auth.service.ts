import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { AuthUser, LoginResponse, Role } from '../models/models';
import { ApiService } from './api.service';

const TOKEN_KEY = 'bms.token';
const USER_KEY = 'bms.user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = inject(ApiService);
  private router = inject(Router);

  readonly user = signal<AuthUser | null>(this.readUser());
  readonly isLoggedIn = computed(() => !!this.user() && !!this.token());
  readonly role = computed<Role | null>(() => this.user()?.role ?? null);
  /** Admin and Manager can write; Viewer is read-only. */
  readonly canWrite = computed(() => this.role() === 'Admin' || this.role() === 'Manager');
  readonly isAdmin = computed(() => this.role() === 'Admin');

  token(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  login(email: string, password: string, remember = true): Observable<LoginResponse> {
    return this.api.post<LoginResponse>('auth/login', { email, password }).pipe(
      tap((res) => {
        localStorage.setItem(TOKEN_KEY, res.token);
        localStorage.setItem(USER_KEY, JSON.stringify(res.user));
        if (!remember) sessionStorage.setItem('bms.session-only', '1');
        this.user.set(res.user);
      }),
    );
  }

  logout(redirect = true): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this.user.set(null);
    if (redirect) this.router.navigate(['/login']);
  }

  private readUser(): AuthUser | null {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) ?? 'null');
    } catch {
      return null;
    }
  }
}
