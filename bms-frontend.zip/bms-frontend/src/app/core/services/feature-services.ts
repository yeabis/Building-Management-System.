import { Injectable, inject, signal } from '@angular/core';
import { Observable, tap } from 'rxjs';
import {
  AppNotification, DashboardStats, FloorSummary, Invoice, Lease, LeaseInput, LegalDocument, PagedResult,
  Payment, PaymentInput, ReportResult, ReportType, Tenant, TenantInput, Unit, UnitInput, UnitStatus,
} from '../models/models';
import { ApiService } from './api.service';

type Q = Record<string, unknown>;

@Injectable({ providedIn: 'root' })
export class UnitsService {
  private api = inject(ApiService);
  list(q: Q): Observable<PagedResult<Unit>> { return this.api.get('units', q); }
  floors(): Observable<FloorSummary[]> { return this.api.get('units/floors'); }
  create(u: UnitInput): Observable<Unit> { return this.api.post('units', u); }
  update(id: number, u: UnitInput): Observable<Unit> { return this.api.put(`units/${id}`, u); }
  changeStatus(id: number, status: UnitStatus): Observable<Unit> { return this.api.put(`units/${id}/status`, { status }); }
  remove(id: number): Observable<void> { return this.api.delete(`units/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class TenantsService {
  private api = inject(ApiService);
  list(q: Q): Observable<PagedResult<Tenant>> { return this.api.get('tenants', q); }
  get(id: number): Observable<Tenant> { return this.api.get(`tenants/${id}`); }
  create(t: TenantInput): Observable<Tenant> { return this.api.post('tenants', t); }
  update(id: number, t: TenantInput): Observable<Tenant> { return this.api.put(`tenants/${id}`, t); }
  deactivate(id: number): Observable<void> { return this.api.put(`tenants/${id}/deactivate`); }
  uploadDocument(id: number, form: FormData): Observable<LegalDocument> { return this.api.post(`tenants/${id}/documents`, form); }
}

@Injectable({ providedIn: 'root' })
export class LeasesService {
  private api = inject(ApiService);
  list(q: Q): Observable<PagedResult<Lease>> { return this.api.get('leases', q); }
  create(l: LeaseInput): Observable<Lease> { return this.api.post('leases', l); }
  renew(id: number, body: { newEndDate: string; newMonthlyRent: number }): Observable<Lease> { return this.api.put(`leases/${id}/renew`, body); }
  terminate(id: number, body: { reason: string }): Observable<Lease> { return this.api.put(`leases/${id}/terminate`, body); }
}

@Injectable({ providedIn: 'root' })
export class PaymentsService {
  private api = inject(ApiService);
  history(q: Q): Observable<PagedResult<Payment>> { return this.api.get('payments', q); }
  outstanding(q: Q): Observable<PagedResult<Invoice>> { return this.api.get('payments/outstanding', q); }
  record(p: PaymentInput): Observable<Payment> { return this.api.post('payments', p); }
  generateInvoices(): Observable<{ generated: number }> { return this.api.post('invoices/generate'); }
}

@Injectable({ providedIn: 'root' })
export class ReportsService {
  private api = inject(ApiService);
  run(type: ReportType, q: Q): Observable<ReportResult> { return this.api.get(`reports/${type}`, q); }
  export(type: ReportType, q: Q): Observable<Blob> { return this.api.blob(`reports/export/${type}`, q); }
}

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private api = inject(ApiService);
  stats(): Observable<DashboardStats> { return this.api.get('dashboard'); }
}

/** Holds the bell-icon state (unread badge + dropdown list) and polls every minute. */
@Injectable({ providedIn: 'root' })
export class NotificationsService {
  private api = inject(ApiService);
  readonly items = signal<AppNotification[]>([]);
  readonly unread = signal(0);
  private timer?: ReturnType<typeof setInterval>;

  load(): Observable<PagedResult<AppNotification>> {
    return this.api.get<PagedResult<AppNotification>>('notifications', { page: 1, pageSize: 50 }).pipe(
      tap((r) => {
        this.items.set(r.items);
        this.unread.set(r.items.filter((n) => !n.isRead).length);
      }),
    );
  }
  start() { this.stop(); this.load().subscribe({ error: () => {} }); this.timer = setInterval(() => this.load().subscribe({ error: () => {} }), 60000); }
  stop() { if (this.timer) clearInterval(this.timer); }
  markRead(id: number): Observable<void> {
    return this.api.put<void>(`notifications/${id}/read`).pipe(tap(() => {
      this.items.update((l) => l.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
      this.unread.set(this.items().filter((n) => !n.isRead).length);
    }));
  }
  markAllRead(): Observable<void> {
    return this.api.put<void>('notifications/read-all').pipe(tap(() => {
      this.items.update((l) => l.map((n) => ({ ...n, isRead: true })));
      this.unread.set(0);
    }));
  }
}
