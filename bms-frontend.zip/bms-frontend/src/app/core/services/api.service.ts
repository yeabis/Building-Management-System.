import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';

/** Thin wrapper over HttpClient: builds URLs, drops empty params, unwraps the { success, data } envelope. */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  readonly base = environment.apiUrl;

  private unwrap<T>(r: any): T {
    return (r && typeof r === 'object' && 'success' in r && 'data' in r ? r.data : r) as T;
  }

  private params(p?: Record<string, unknown>): HttpParams {
    let hp = new HttpParams();
    Object.entries(p ?? {}).forEach(([k, v]) => {
      if (v !== null && v !== undefined && v !== '') hp = hp.set(k, String(v));
    });
    return hp;
  }

  get<T>(path: string, params?: Record<string, unknown>): Observable<T> {
    return this.http.get(`${this.base}/${path}`, { params: this.params(params) }).pipe(map((r) => this.unwrap<T>(r)));
  }
  post<T>(path: string, body: unknown = {}): Observable<T> {
    return this.http.post(`${this.base}/${path}`, body).pipe(map((r) => this.unwrap<T>(r)));
  }
  put<T>(path: string, body: unknown = {}): Observable<T> {
    return this.http.put(`${this.base}/${path}`, body).pipe(map((r) => this.unwrap<T>(r)));
  }
  delete<T>(path: string): Observable<T> {
    return this.http.delete(`${this.base}/${path}`).pipe(map((r) => this.unwrap<T>(r)));
  }
  blob(path: string, params?: Record<string, unknown>): Observable<Blob> {
    return this.http.get(`${this.base}/${path}`, { params: this.params(params), responseType: 'blob' });
  }
}
