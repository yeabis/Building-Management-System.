import { Injectable, computed, signal } from '@angular/core';

/** Counts in-flight HTTP calls so the shell can show a global progress bar. */
@Injectable({ providedIn: 'root' })
export class LoadingService {
  private count = signal(0);
  readonly busy = computed(() => this.count() > 0);
  start() { this.count.update((c) => c + 1); }
  stop() { this.count.update((c) => Math.max(0, c - 1)); }
}
