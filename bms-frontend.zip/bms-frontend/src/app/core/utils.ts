import { AbstractControl, ValidationErrors } from '@angular/forms';

export const today = () => new Date().toISOString().slice(0, 10);
export const plusMonths = (iso: string, n: number) => {
  const d = new Date(iso);
  d.setMonth(d.getMonth() + n);
  return d.toISOString().slice(0, 10);
};
export const initials = (name: string) =>
  name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]?.toUpperCase()).join('');
export const daysUntil = (iso: string | null) =>
  iso ? Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000) : null;
export const label = (s: string) => s.replace(/([a-z])([A-Z])/g, '$1 $2');
export const monthName = (m: number) =>
  ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][m - 1];

export function endAfterStart(group: AbstractControl): ValidationErrors | null {
  const s = group.get('startDate')?.value;
  const e = group.get('endDate')?.value;
  return s && e && new Date(e) <= new Date(s) ? { endBeforeStart: true } : null;
}

export function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
