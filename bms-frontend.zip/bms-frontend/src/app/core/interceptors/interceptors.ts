import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, finalize, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuthService } from '../services/auth.service';
import { LoadingService } from '../services/loading.service';
import { ToastService } from '../services/toast.service';

const isApi = (url: string) => url.startsWith(environment.apiUrl);
const isLogin = (url: string) => url.includes('/auth/login');

/** Attach the JWT as a Bearer token to every API request. */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = inject(AuthService).token();
  if (token && isApi(req.url) && !isLogin(req.url)) {
    req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
  }
  return next(req);
};

/** 401 -> back to login, 403 -> forbidden message, 5xx / network -> error toast, other -> server message. */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const toast = inject(ToastService);
  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      if (!isApi(req.url)) return throwError(() => err);
      const serverMsg: string | undefined = err.error?.message ?? err.error?.title;
      if (err.status === 401) {
        if (!isLogin(req.url)) {
          auth.logout();
          toast.error('Your session has expired. Please sign in again.');
        }
      } else if (err.status === 403) {
        toast.error('You do not have permission to perform this action.');
      } else if (err.status === 0) {
        toast.error('Cannot reach the server. Check your connection.');
      } else if (err.status >= 500) {
        toast.error(serverMsg ?? 'Something went wrong on the server.');
      } else if (serverMsg) {
        toast.error(serverMsg);
      }
      return throwError(() => err);
    }),
  );
};

/** Drives the global progress bar. */
export const loadingInterceptor: HttpInterceptorFn = (req, next) => {
  const loading = inject(LoadingService);
  if (!isApi(req.url)) return next(req);
  loading.start();
  return next(req).pipe(finalize(() => loading.stop()));
};
