export type Role = 'Admin' | 'Manager' | 'Viewer';
export type UnitType = 'Shop' | 'Office';
export type UnitStatus = 'Available' | 'Occupied' | 'UnderMaintenance' | 'Reserved';
export type LeaseStatus = 'Active' | 'Expired' | 'Terminated' | 'PendingRenewal';
export type InvoiceStatus = 'Draft' | 'Issued' | 'Paid' | 'Overdue' | 'Cancelled';
export type PaymentMethod = 'Cash' | 'BankTransfer' | 'Cheque' | 'MobileMoney';
export type BusinessType = 'Retail' | 'Restaurant' | 'Office' | 'Services' | 'Healthcare' | 'Education' | 'Other';
export type DocumentType = 'BusinessLicense' | 'TradeLicense' | 'TaxClearance' | 'NationalID' | 'LeaseContract' | 'Other';
export type NotificationType = 'PaymentDue' | 'PaymentOverdue' | 'LeaseExpiry' | 'DocumentExpiry' | 'General';

export const UNIT_STATUSES: UnitStatus[] = ['Available', 'Occupied', 'UnderMaintenance', 'Reserved'];
export const UNIT_TYPES: UnitType[] = ['Shop', 'Office'];
export const BUSINESS_TYPES: BusinessType[] = ['Retail', 'Restaurant', 'Office', 'Services', 'Healthcare', 'Education', 'Other'];
export const DOCUMENT_TYPES: DocumentType[] = ['BusinessLicense', 'TradeLicense', 'TaxClearance', 'NationalID', 'LeaseContract', 'Other'];
export const PAYMENT_METHODS: PaymentMethod[] = ['Cash', 'BankTransfer', 'Cheque', 'MobileMoney'];
export const LEASE_STATUSES: LeaseStatus[] = ['Active', 'PendingRenewal', 'Expired', 'Terminated'];

export interface ApiResponse<T> { success: boolean; data: T; message?: string }
export interface PagedResult<T> { items: T[]; totalCount: number; page: number; pageSize: number }

export interface AuthUser { id: string; fullName: string; email: string; role: Role }
export interface LoginResponse { token: string; refreshToken: string; expiresAt: string; user: AuthUser }

export interface Unit {
  id: number;
  floorNumber: number;
  unitNumber: string;
  unitType: UnitType;
  areaSqMeters: number;
  monthlyRent: number;
  status: UnitStatus;
  description: string;
  tenantName?: string | null;
}
export interface UnitInput {
  floorNumber: number; unitNumber: string; unitType: UnitType;
  areaSqMeters: number; monthlyRent: number; status: UnitStatus; description: string;
}
export interface FloorSummary {
  floorNumber: number;
  totalUnits: number;
  occupied: number;
  available: number;
  underMaintenance: number;
  reserved: number;
  units: Unit[];
}

export interface LegalDocument {
  id: number; tenantId: number; documentType: DocumentType; fileName: string;
  uploadedAt: string; expiryDate: string | null; isVerified: boolean;
}
export interface Tenant {
  id: number;
  organizationName: string;
  tinNumber: string;
  phone: string;
  businessType: BusinessType;
  contactPersonName: string;
  contactEmail: string;
  isActive: boolean;
  activeUnits: string[];
  documents?: LegalDocument[];
}
export interface TenantInput {
  organizationName: string; tinNumber: string; phone: string;
  businessType: BusinessType; contactPersonName: string; contactEmail: string;
}

export interface Lease {
  id: number; unitId: number; unitNumber: string; tenantId: number; tenantName: string;
  startDate: string; endDate: string; monthlyRent: number; depositAmount: number;
  status: LeaseStatus; terminationReason?: string | null;
}
export interface LeaseInput { unitId: number; tenantId: number; startDate: string; endDate: string; monthlyRent: number; depositAmount: number }

export interface Invoice {
  id: number; leaseId: number; invoiceNumber: string; tenantName: string; unitNumber: string;
  amountDue: number; amountPaid: number; balance: number;
  dueDate: string; issueDate: string; status: InvoiceStatus; periodMonth: number; periodYear: number;
}
export interface Payment {
  id: number; invoiceId: number; invoiceNumber: string; tenantName: string;
  amountPaid: number; paymentDate: string; paymentMethod: PaymentMethod;
  referenceNumber: string; notes?: string | null;
}
export interface PaymentInput { invoiceId: number; amountPaid: number; paymentDate: string; paymentMethod: PaymentMethod; referenceNumber: string; notes: string }

export interface AppNotification {
  id: number; title: string; message: string; notificationType: NotificationType; isRead: boolean; createdAt: string;
}

export interface DashboardStats {
  occupancyPercent: number;
  totalRevenue: number;
  outstanding: number;
  vacantUnits: number;
  totalUnits: number;
  revenueByMonth: { month: string; expected: number; collected: number }[];
  occupancyByFloor: { floor: number; occupied: number; vacant: number }[];
}

export type ReportType = 'occupancy' | 'revenue' | 'arrears' | 'lease-expiry' | 'document-expiry';
export interface ReportResult { rows: Record<string, any>[]; summary: { label: string; value: string | number }[] }
