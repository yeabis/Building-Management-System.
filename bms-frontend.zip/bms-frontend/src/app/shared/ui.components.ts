import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { ToastService } from '../core/services/toast.service';
import { label } from '../core/utils';
import { IconComponent } from './icon.component';

/* ---------- Modal ---------- */
@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [IconComponent],
  template: `
    <div class="backdrop" (mousedown)="closed.emit()">
      <div class="modal" role="dialog" aria-modal="true" [style.width.px]="width" (mousedown)="$event.stopPropagation()">
        <header>
          <h3>{{ title }}</h3>
          <button type="button" class="icon-btn" aria-label="Close" (click)="closed.emit()"><app-icon name="x" /></button>
        </header>
        <div class="modal-body"><ng-content /></div>
      </div>
    </div>
  `,
})
export class ModalComponent {
  @Input() title = '';
  @Input() width = 560;
  @Output() closed = new EventEmitter<void>();
}

/* ---------- Status chip ---------- */
const TONE: Record<string, string> = {
  Active: 'green', Occupied: 'green', Paid: 'green', Verified: 'green', Available: '', Issued: 'blue',
  Reserved: 'blue', PendingRenewal: 'amber', UnderMaintenance: 'amber', Draft: '', Pending: 'amber',
  Overdue: 'red', Expired: 'red', Terminated: 'red', Cancelled: 'red', Inactive: '',
  PaymentOverdue: 'red', PaymentDue: 'amber', LeaseExpiry: 'amber', DocumentExpiry: 'amber', General: 'blue',
};

@Component({
  selector: 'app-chip',
  standalone: true,
  template: `<span class="chip" [class]="'chip ' + tone">{{ text }}</span>`,
})
export class ChipComponent {
  @Input({ required: true }) value = '';
  get tone() { return TONE[this.value] ?? ''; }
  get text() { return label(this.value); }
}

/* ---------- Inline field error ---------- */
@Component({
  selector: 'app-field-error',
  standalone: true,
  template: `@if (control && control.invalid && (control.touched || control.dirty)) { <small class="err">{{ message() }}</small> }`,
})
export class FieldErrorComponent {
  @Input() control: AbstractControl | null = null;
  @Input() patternMessage = 'Invalid format';
  message(): string {
    const e = this.control?.errors;
    if (!e) return '';
    if (e['required']) return 'This field is required';
    if (e['email']) return 'Enter a valid email address';
    if (e['pattern']) return this.patternMessage;
    if (e['minlength']) return `Minimum ${e['minlength'].requiredLength} characters`;
    if (e['min']) return `Must be at least ${e['min'].min}`;
    if (e['max']) return `Must be at most ${e['max'].max}`;
    return 'Invalid value';
  }
}

/* ---------- Server-side pagination footer ---------- */
@Component({
  selector: 'app-pagination',
  standalone: true,
  template: `
    <div class="pager">
      <span class="muted">Showing {{ from }}–{{ to }} of {{ total }}</span>
      <div class="pager-btns">
        <button class="btn sm" [disabled]="page <= 1" (click)="pageChange.emit(page - 1)">Previous</button>
        <span class="pager-info">Page {{ page }} of {{ pages }}</span>
        <button class="btn sm" [disabled]="page >= pages" (click)="pageChange.emit(page + 1)">Next</button>
      </div>
    </div>
  `,
  styles: [`.pager{display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid var(--line);font-size:12px}.pager-btns{display:flex;align-items:center;gap:10px}.pager-info{font-weight:600}`],
})
export class PaginationComponent {
  @Input() page = 1;
  @Input() pageSize = 10;
  @Input() total = 0;
  @Output() pageChange = new EventEmitter<number>();
  get pages() { return Math.max(1, Math.ceil(this.total / this.pageSize)); }
  get from() { return this.total ? (this.page - 1) * this.pageSize + 1 : 0; }
  get to() { return Math.min(this.total, this.page * this.pageSize); }
}

/* ---------- Spinner row ---------- */
@Component({
  selector: 'app-spinner',
  standalone: true,
  template: `<div class="loading-row"><span class="spinner"></span></div>`,
})
export class SpinnerComponent {}

/* ---------- Toasts ---------- */
@Component({
  selector: 'app-toasts',
  standalone: true,
  imports: [IconComponent],
  template: `
    <div class="toast-host">
      @for (t of toast.toasts(); track t.id) {
        <div class="toast" [class]="'toast ' + t.type" (click)="toast.dismiss(t.id)">
          <app-icon [name]="t.type === 'success' ? 'check' : 'alert'" [size]="16" />
          <span>{{ t.message }}</span>
        </div>
      }
    </div>
  `,
  styles: [`
    .toast-host{position:fixed;right:20px;top:20px;display:flex;flex-direction:column;gap:8px;z-index:100;max-width:380px}
    .toast{display:flex;gap:10px;align-items:center;padding:12px 14px;border-radius:10px;background:var(--ink);color:#fff;box-shadow:var(--shadow-lg);cursor:pointer;font-size:13px;animation:in .2s}
    .toast.error{background:#991b1b}.toast.success{background:#166534}
    @keyframes in{from{transform:translateY(-8px);opacity:0}}
  `],
})
export class ToastsComponent {
  toast = inject(ToastService);
}
