import { Component, Input } from '@angular/core';

export interface BarSeries { name: string; values: number[]; color: string }

const compact = (n: number) => (n >= 1e6 ? `${+(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `${+(n / 1e3).toFixed(0)}k` : `${n}`);

/** Dependency-free grouped bar chart (SVG). */
@Component({
  selector: 'app-bar-chart',
  standalone: true,
  template: `
    <svg [attr.viewBox]="'0 0 ' + W + ' ' + H" width="100%" role="img">
      @for (t of ticks; track t) {
        <line [attr.x1]="L" [attr.x2]="W" [attr.y1]="y(t)" [attr.y2]="y(t)" stroke="#e5e7eb" />
        <text [attr.x]="L - 8" [attr.y]="y(t) + 4" text-anchor="end" font-size="11" fill="#64748b">{{ fmt(t) }}</text>
      }
      @for (lab of labels; track $index; let li = $index) {
        @for (s of series; track s.name; let si = $index) {
          <rect [attr.x]="barX(li, si)" [attr.y]="y(s.values[li] ?? 0)" [attr.width]="bw"
                [attr.height]="B - y(s.values[li] ?? 0)" [attr.fill]="s.color" rx="3">
            <title>{{ s.name }}: {{ s.values[li] ?? 0 }}</title>
          </rect>
        }
        <text [attr.x]="L + step * (li + 0.5)" [attr.y]="H - 8" text-anchor="middle" font-size="11" fill="#64748b">{{ lab }}</text>
      }
    </svg>
    @if (series.length > 1) {
      <div class="legend">@for (s of series; track s.name) { <span><i [style.background]="s.color"></i>{{ s.name }}</span> }</div>
    }
  `,
  styles: [`.legend{display:flex;gap:16px;margin-top:6px;font-size:12px;color:var(--muted)}.legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px}`],
})
export class BarChartComponent {
  @Input() labels: string[] = [];
  @Input() series: BarSeries[] = [];
  readonly W = 640; readonly H = 240; readonly L = 44; readonly B = 212; readonly T = 12;

  get max() { return Math.max(1, ...this.series.flatMap((s) => s.values)); }
  get niceMax() { const p = Math.pow(10, Math.floor(Math.log10(this.max))); return Math.ceil(this.max / p) * p; }
  get ticks() { return [0, 1, 2, 3, 4].map((i) => (this.niceMax / 4) * i); }
  get step() { return (this.W - this.L) / Math.max(1, this.labels.length); }
  get bw() { return Math.min(26, (this.step * 0.7) / Math.max(1, this.series.length)); }
  y(v: number) { return this.B - (v / this.niceMax) * (this.B - this.T); }
  barX(i: number, si: number) {
    const group = this.bw * this.series.length;
    return this.L + this.step * i + (this.step - group) / 2 + si * this.bw;
  }
  fmt = compact;
}

/** Donut gauge for a single percentage. */
@Component({
  selector: 'app-donut',
  standalone: true,
  template: `
    <svg viewBox="0 0 120 120" [attr.width]="size" [attr.height]="size">
      <circle cx="60" cy="60" r="48" fill="none" stroke="#e5e7eb" stroke-width="14" />
      <circle cx="60" cy="60" r="48" fill="none" [attr.stroke]="color" stroke-width="14" stroke-linecap="round"
              [attr.stroke-dasharray]="dash" transform="rotate(-90 60 60)" />
      <text x="60" y="58" text-anchor="middle" font-size="22" font-weight="700" fill="#0f172a">{{ value }}%</text>
      <text x="60" y="76" text-anchor="middle" font-size="10" fill="#64748b">{{ caption }}</text>
    </svg>
  `,
})
export class DonutComponent {
  @Input() value = 0;
  @Input() caption = 'occupied';
  @Input() color = '#1d4ed8';
  @Input() size = 160;
  get dash() { const c = 2 * Math.PI * 48; return `${(Math.min(100, this.value) / 100) * c} ${c}`; }
}
