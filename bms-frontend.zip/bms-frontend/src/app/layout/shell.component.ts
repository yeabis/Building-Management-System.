import { Component, HostListener, OnDestroy, OnInit, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../core/services/auth.service';
import { LoadingService } from '../core/services/loading.service';
import { NotificationsService } from '../core/services/feature-services';
import { initials } from '../core/utils';
import { IconComponent } from '../shared/icon.component';
import { ChipComponent } from '../shared/ui.components';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, IconComponent, DatePipe, ChipComponent],
  template: `
    @if (loading.busy()) { <div class="topbar-progress"></div> }
    <div class="shell">
      <aside class="side">
        <div class="brand">
          <span class="logo"><app-icon name="building" [size]="18" /></span>
          <div><b>Glory Building</b><small>Commercial Asset Ledger</small></div>
        </div>
        <div class="side-label">Menu</div>
        <nav>
          @for (n of nav(); track n.path) {
            <a class="nav" [routerLink]="n.path" routerLinkActive="on"><app-icon [name]="n.icon" /> {{ n.label }}</a>
          }
        </nav>
        <div class="side-foot">
          <div class="who">
            <span class="avatar">{{ ini() }}</span>
            <div><b>{{ auth.user()?.fullName }}</b><small>{{ auth.user()?.role }}</small></div>
          </div>
          <button class="btn sm block-btn" (click)="auth.logout()"><app-icon name="logout" [size]="15" /> Sign out</button>
        </div>
      </aside>

      <div class="main">
        <header class="top">
          <div class="crumb"><span class="muted">7 floors · 42 units</span></div>
          <div class="top-right">
            <div class="bell-wrap">
              <button class="icon-btn" aria-label="Notifications" (click)="toggleBell($event)">
                <app-icon name="bell" [size]="20" />
                @if (notes.unread() > 0) { <span class="badge">{{ notes.unread() > 9 ? '9+' : notes.unread() }}</span> }
              </button>
              @if (bellOpen()) {
                <div class="dropdown" (click)="$event.stopPropagation()">
                  <div class="dd-head">
                    <b>Notifications</b>
                    <button class="link-btn" [disabled]="notes.unread() === 0" (click)="markAll()">Mark all as read</button>
                  </div>
                  <div class="dd-list">
                    @for (n of notes.items().slice(0, 6); track n.id) {
                      <button class="dd-item" [class.unread]="!n.isRead" (click)="open(n.id)">
                        <div class="row-flex"><app-chip [value]="n.notificationType" /><small class="muted">{{ n.createdAt | date: 'MMM d, HH:mm' }}</small></div>
                        <b>{{ n.title }}</b>
                        <span class="muted">{{ n.message }}</span>
                      </button>
                    } @empty { <p class="muted pad">You're all caught up.</p> }
                  </div>
                  <a class="dd-foot" routerLink="/notifications" (click)="bellOpen.set(false)">View all notifications</a>
                </div>
              }
            </div>
            <span class="avatar sm">{{ ini() }}</span>
          </div>
        </header>
        <main><router-outlet /></main>
      </div>
    </div>
  `,
  styles: [`
    .shell{display:grid;grid-template-columns:248px 1fr;min-height:100vh}
    .side{background:#fff;border-right:1px solid var(--line);padding:20px 14px;display:flex;flex-direction:column;position:sticky;top:0;height:100vh}
    .brand{display:flex;gap:10px;align-items:center;padding:4px 8px 22px}
    .brand b{display:block;font-size:14px}.brand small{color:var(--muted);font-size:11px}
    .logo{width:36px;height:36px;border-radius:10px;background:var(--ink);color:#fff;display:grid;place-items:center}
    .side-label{font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);padding:0 10px 8px;font-weight:600}
    nav{display:flex;flex-direction:column;gap:2px}
    .nav{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;color:var(--ink-2);font-weight:500}
    .nav:hover{background:var(--soft)}
    .nav.on{background:var(--ink);color:#fff}
    .side-foot{margin-top:auto;border-top:1px solid var(--line);padding-top:14px;display:flex;flex-direction:column;gap:10px}
    .who{display:flex;gap:10px;align-items:center}.who b{display:block;font-size:13px}.who small{color:var(--muted);font-size:11px}
    .block-btn{width:100%}
    .main{min-width:0;display:flex;flex-direction:column}
    .top{height:60px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;padding:0 28px;position:sticky;top:0;z-index:20}
    .top-right{display:flex;align-items:center;gap:10px}
    .avatar.sm{width:30px;height:30px;border-radius:50%}
    .topbar-progress{position:fixed;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--primary),#60a5fa,var(--primary));background-size:200% 100%;animation:slide 1s linear infinite;z-index:90}
    @keyframes slide{to{background-position:-200% 0}}
    .bell-wrap{position:relative}
    .badge{position:absolute;top:2px;right:2px;min-width:16px;height:16px;padding:0 4px;border-radius:99px;background:var(--red);color:#fff;font-size:10px;font-weight:700;display:grid;place-items:center}
    .dropdown{position:absolute;right:0;top:44px;width:360px;background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow-lg);overflow:hidden}
    .dd-head{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid var(--line)}
    .dd-list{max-height:360px;overflow:auto}
    .dd-item{display:flex;flex-direction:column;gap:3px;width:100%;text-align:left;border:0;background:#fff;padding:12px 16px;border-bottom:1px solid var(--line);cursor:pointer;font-family:inherit;font-size:13px}
    .dd-item:hover{background:#f8fafc}.dd-item.unread{background:#f5f8ff}
    .dd-foot{display:block;text-align:center;padding:12px;font-weight:600;font-size:13px}
    .pad{padding:20px;text-align:center;margin:0}
    @media (max-width:860px){.shell{grid-template-columns:1fr}.side{display:none}}
  `],
})
export class ShellComponent implements OnInit, OnDestroy {
  auth = inject(AuthService);
  loading = inject(LoadingService);
  notes = inject(NotificationsService);
  private router = inject(Router);
  bellOpen = signal(false);

  nav = () => [
    { path: '/dashboard', label: 'Dashboard', icon: 'dashboard' },
    { path: '/units', label: 'Units Management', icon: 'building' },
    { path: '/tenants', label: 'Tenants Directory', icon: 'users' },
    { path: '/leases', label: 'Lease Agreements', icon: 'file' },
    { path: '/payments', label: 'Billing & Payments', icon: 'wallet' },
    { path: '/reports', label: 'Reports', icon: 'chart' },
  ];
  ini = () => initials(this.auth.user()?.fullName ?? '');

  ngOnInit() { this.notes.start(); }
  ngOnDestroy() { this.notes.stop(); }

  @HostListener('document:click') closeBell() { this.bellOpen.set(false); }
  toggleBell(e: Event) { e.stopPropagation(); this.bellOpen.update((v) => !v); }
  markAll() { this.notes.markAllRead().subscribe(); }
  open(id: number) { this.notes.markRead(id).subscribe(); this.bellOpen.set(false); this.router.navigate(['/notifications']); }
}
