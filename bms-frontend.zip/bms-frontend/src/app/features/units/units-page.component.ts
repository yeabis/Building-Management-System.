import { CurrencyPipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { debounceTime } from 'rxjs';
import { FloorSummary, Unit, UnitStatus, UNIT_STATUSES, UNIT_TYPES } from '../../core/models/models';
import { AuthService } from '../../core/services/auth.service';
import { UnitsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { label } from '../../core/utils';
import { IconComponent } from '../../shared/icon.component';
import { ChipComponent, PaginationComponent, SpinnerComponent } from '../../shared/ui.components';
import { UnitFormComponent } from './unit-form.component';

@Component({
  selector: 'app-units-page',
  standalone: true,
  imports: [ReactiveFormsModule, CurrencyPipe, DecimalPipe, IconComponent, ChipComponent, PaginationComponent, SpinnerComponent, UnitFormComponent],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <div class="eyebrow">Property inventory</div>
          <h1>Units Management</h1>
          <p>Floor-by-floor view of every shop and office in the building.</p>
        </div>
        <div class="actions">
          <div class="tabs">
            <button [class.on]="view() === 'plan'" (click)="view.set('plan')"><app-icon name="grid" [size]="14" /> Floor plan</button>
            <button [class.on]="view() === 'list'" (click)="view.set('list')"><app-icon name="list" [size]="14" /> List</button>
          </div>
          @if (auth.canWrite()) {
            <button class="btn primary" (click)="openForm(null)"><app-icon name="plus" [size]="16" /> Add unit</button>
          }
        </div>
      </div>

      @if (view() === 'plan') {
        @if (loadingPlan()) { <app-spinner /> } @else {
          <div class="plan-layout">
            <div class="card card-pad">
              <div class="legend">
                <span><i class="dot occupied"></i>Occupied ({{ count('Occupied') }})</span>
                <span><i class="dot available"></i>Available ({{ count('Available') }})</span>
                <span><i class="dot UnderMaintenance"></i>Under maintenance ({{ count('UnderMaintenance') }})</span>
                <span><i class="dot reserved"></i>Reserved ({{ count('Reserved') }})</span>
              </div>
              <div class="plan">
                @for (f of floorsDesc(); track f.floorNumber) {
                  <div class="plan-row" [class.sel-floor]="selectedFloor()?.floorNumber === f.floorNumber">
                    <button class="floor-tag" (click)="selectFloor(f)">Floor {{ f.floorNumber }}</button>
                    <div class="cells">
                      @for (u of f.units; track u.id) {
                        <button class="cell" [class]="'cell ' + u.status" [class.picked]="selected()?.id === u.id" (click)="pick(u, f)" [title]="u.unitNumber + ' · ' + label(u.status)">
                          {{ u.unitNumber }}
                        </button>
                      }
                    </div>
                  </div>
                }
              </div>
            </div>

            <div class="side">
              <div class="card card-pad">
                @if (selected(); as u) {
                  <div class="row-flex" style="justify-content:space-between">
                    <h3>Unit {{ u.unitNumber }}</h3><app-chip [value]="u.status" />
                  </div>
                  <dl class="kv" style="margin-top:14px">
                    <dt>Type</dt><dd>{{ u.unitType }}</dd>
                    <dt>Floor</dt><dd>{{ u.floorNumber }}</dd>
                    <dt>Area</dt><dd>{{ u.areaSqMeters }} m²</dd>
                    <dt>Monthly rent</dt><dd>{{ u.monthlyRent | currency: 'ETB' : 'code' : '1.0-0' }}</dd>
                    <dt>Tenant</dt><dd>{{ u.tenantName ?? '—' }}</dd>
                    <dt>Description</dt><dd>{{ u.description || '—' }}</dd>
                  </dl>
                  @if (auth.canWrite()) {
                    <div class="divider"></div>
                    <div class="field">
                      <label for="chg">Change status</label>
                      <select id="chg" class="input" [value]="u.status" (change)="changeStatus(u, $any($event.target).value)">
                        @for (s of statuses; track s) { <option [value]="s">{{ label(s) }}</option> }
                      </select>
                    </div>
                    <div class="actions">
                      <button class="btn sm" (click)="openForm(u)"><app-icon name="edit" [size]="14" /> Edit</button>
                      <button class="btn sm" (click)="remove(u)"><app-icon name="trash" [size]="14" /> Delete</button>
                    </div>
                  }
                } @else {
                  <h3>Unit details</h3>
                  <p class="muted">Select a unit on the floor plan to see its details.</p>
                }
              </div>

              <div class="card card-pad">
                @if (selectedFloor(); as f) {
                  <h3>Floor {{ f.floorNumber }}</h3>
                  <p class="muted" style="margin:4px 0 12px">{{ f.occupied }} of {{ f.totalUnits }} units occupied</p>
                  <div class="progress"><span [style.width.%]="(f.occupied / f.totalUnits) * 100"></span></div>
                  <dl class="kv" style="margin-top:14px">
                    <dt>Occupied</dt><dd>{{ f.occupied }}</dd>
                    <dt>Available</dt><dd>{{ f.available }}</dd>
                    <dt>Maintenance</dt><dd>{{ f.underMaintenance }}</dd>
                    <dt>Reserved</dt><dd>{{ f.reserved }}</dd>
                    <dt>Rent roll</dt><dd>{{ rentRoll(f) | number: '1.0-0' }} ETB / mo</dd>
                  </dl>
                } @else {
                  <h3>Floor info</h3>
                  <p class="muted">Click a floor label or a unit to see floor totals.</p>
                }
              </div>
            </div>
          </div>
        }
      } @else {
        <div class="card">
          <form class="toolbar" [formGroup]="filters">
            <div class="search"><app-icon name="search" [size]="16" /><input class="input" formControlName="search" placeholder="Search unit number or description" /></div>
            <select class="input" formControlName="floor"><option value="">All floors</option>@for (f of [1,2,3,4,5,6,7]; track f) { <option [value]="f">Floor {{ f }}</option> }</select>
            <select class="input" formControlName="unitType"><option value="">All types</option>@for (t of types; track t) { <option [value]="t">{{ t }}</option> }</select>
            <select class="input" formControlName="status"><option value="">All statuses</option>@for (s of statuses; track s) { <option [value]="s">{{ label(s) }}</option> }</select>
          </form>
          <div class="table-wrap">
            <table class="table">
              <thead><tr><th>Unit</th><th>Floor</th><th>Type</th><th class="num">Area</th><th class="num">Monthly rent</th><th>Status</th><th>Tenant</th><th></th></tr></thead>
              <tbody>
                @if (loadingList()) { <tr><td colspan="8"><app-spinner /></td></tr> }
                @else {
                  @for (u of rows(); track u.id) {
                    <tr>
                      <td class="cell-main">{{ u.unitNumber }}</td><td>{{ u.floorNumber }}</td><td>{{ u.unitType }}</td>
                      <td class="num">{{ u.areaSqMeters }} m²</td><td class="num">{{ u.monthlyRent | currency: 'ETB' : 'code' : '1.0-0' }}</td>
                      <td><app-chip [value]="u.status" /></td><td>{{ u.tenantName ?? '—' }}</td>
                      <td class="num">
                        @if (auth.canWrite()) {
                          <button class="btn sm ghost" (click)="openForm(u)"><app-icon name="edit" [size]="14" /></button>
                          <button class="btn sm ghost" (click)="remove(u)"><app-icon name="trash" [size]="14" /></button>
                        }
                      </td>
                    </tr>
                  } @empty { <tr><td colspan="8" class="empty">No units match these filters.</td></tr> }
                }
              </tbody>
            </table>
          </div>
          <app-pagination [page]="page()" [pageSize]="pageSize" [total]="total()" (pageChange)="goTo($event)" />
        </div>
      }
    </div>

    @if (formOpen()) {
      <app-unit-form [unit]="editing()" [defaultFloor]="selectedFloor()?.floorNumber ?? 1" (closed)="formOpen.set(false)" (saved)="onSaved()" />
    }
  `,
  styles: [`
    .plan-layout{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(300px,1fr);gap:16px;align-items:start}
    @media (max-width:1000px){.plan-layout{grid-template-columns:1fr}}
    .side{display:flex;flex-direction:column;gap:16px}
    .legend{display:flex;gap:18px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin-bottom:16px}
    .dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px}
    .dot.occupied{background:#22c55e}.dot.available{background:#d1d5db}.dot.UnderMaintenance{background:#facc15}.dot.reserved{background:#60a5fa}
    .plan{display:flex;flex-direction:column;gap:8px}
    .plan-row{display:grid;grid-template-columns:74px 1fr;gap:10px;align-items:center;padding:6px;border-radius:12px}
    .plan-row.sel-floor{background:#f5f8ff}
    .floor-tag{border:0;background:transparent;font-weight:600;color:var(--muted);text-align:left;cursor:pointer;font-size:12px}
    .cells{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px}
    .cell{height:38px;border-radius:8px;border:2px solid transparent;font-size:12px;font-weight:600;cursor:pointer;transition:transform .1s}
    .cell:hover{transform:translateY(-1px)}
    .cell.Occupied{background:#22c55e;color:#fff}
    .cell.Available{background:#e5e7eb;color:var(--ink-2)}
    .cell.UnderMaintenance{background:#facc15;color:#422006}
    .cell.Reserved{background:#60a5fa;color:#fff}
    .cell.picked{border-color:var(--ink);box-shadow:0 0 0 3px rgba(15,23,42,.15)}
  `],
})
export class UnitsPageComponent implements OnInit {
  private svc = inject(UnitsService);
  private fb = inject(FormBuilder).nonNullable;
  private toast = inject(ToastService);
  auth = inject(AuthService);

  label = label;
  statuses = UNIT_STATUSES;
  types = UNIT_TYPES;
  pageSize = 10;

  view = signal<'plan' | 'list'>('plan');
  floors = signal<FloorSummary[]>([]);
  floorsDesc = computed(() => [...this.floors()].sort((a, b) => b.floorNumber - a.floorNumber));
  selected = signal<Unit | null>(null);
  selectedFloor = signal<FloorSummary | null>(null);
  loadingPlan = signal(true);

  rows = signal<Unit[]>([]);
  total = signal(0);
  page = signal(1);
  loadingList = signal(false);

  formOpen = signal(false);
  editing = signal<Unit | null>(null);

  filters = this.fb.group({ search: [''], floor: [''], unitType: [''], status: [''] });

  ngOnInit() {
    this.loadPlan();
    this.loadList();
    this.filters.valueChanges.pipe(debounceTime(300)).subscribe(() => { this.page.set(1); this.loadList(); });
  }

  count(status: UnitStatus) { return this.floors().reduce((s, f) => s + f.units.filter((u) => u.status === status).length, 0); }
  rentRoll(f: FloorSummary) { return f.units.filter((u) => u.status === 'Occupied').reduce((s, u) => s + u.monthlyRent, 0); }
  pick(u: Unit, f: FloorSummary) { this.selected.set(u); this.selectedFloor.set(f); }
  selectFloor(f: FloorSummary) { this.selectedFloor.set(f); }

  loadPlan() {
    this.svc.floors().subscribe((f) => {
      this.floors.set(f);
      this.loadingPlan.set(false);
      const sel = this.selected();
      if (sel) {
        const fl = f.find((x) => x.floorNumber === sel.floorNumber);
        this.selectedFloor.set(fl ?? null);
        this.selected.set(fl?.units.find((u) => u.id === sel.id) ?? null);
      }
    });
  }

  loadList() {
    this.loadingList.set(true);
    this.svc.list({ ...this.filters.getRawValue(), page: this.page(), pageSize: this.pageSize }).subscribe({
      next: (r) => { this.rows.set(r.items); this.total.set(r.totalCount); this.loadingList.set(false); },
      error: () => this.loadingList.set(false),
    });
  }

  goTo(p: number) { this.page.set(p); this.loadList(); }
  openForm(u: Unit | null) { this.editing.set(u); this.formOpen.set(true); }
  onSaved() { this.formOpen.set(false); this.loadPlan(); this.loadList(); }

  changeStatus(u: Unit, status: UnitStatus) {
    this.svc.changeStatus(u.id, status).subscribe({
      next: () => { this.toast.success(`${u.unitNumber} is now ${label(status)}`); this.loadPlan(); this.loadList(); },
      error: () => this.loadPlan(),
    });
  }

  remove(u: Unit) {
    if (!confirm(`Delete unit ${u.unitNumber}? This cannot be undone.`)) return;
    this.svc.remove(u.id).subscribe(() => {
      this.toast.success(`Unit ${u.unitNumber} deleted`);
      if (this.selected()?.id === u.id) this.selected.set(null);
      this.loadPlan(); this.loadList();
    });
  }
}
