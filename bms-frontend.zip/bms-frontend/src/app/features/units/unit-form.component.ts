import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Unit, UNIT_STATUSES, UNIT_TYPES } from '../../core/models/models';
import { UnitsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { label } from '../../core/utils';
import { FieldErrorComponent, ModalComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-unit-form',
  standalone: true,
  imports: [ReactiveFormsModule, ModalComponent, FieldErrorComponent],
  template: `
    <app-modal [title]="unit ? 'Edit unit ' + unit.unitNumber : 'Add unit'" (closed)="closed.emit()">
      <form [formGroup]="form" (ngSubmit)="submit()" novalidate>
        <div class="form-grid">
          <div class="field">
            <label for="un">Unit number</label>
            <input id="un" class="input" formControlName="unitNumber" placeholder="L701" />
            <app-field-error [control]="form.controls.unitNumber" />
          </div>
          <div class="field">
            <label for="fl">Floor</label>
            <select id="fl" class="input" formControlName="floorNumber">
              @for (f of floors; track f) { <option [ngValue]="f">Floor {{ f }}</option> }
            </select>
          </div>
          <div class="field">
            <label for="ut">Type</label>
            <select id="ut" class="input" formControlName="unitType">@for (t of types; track t) { <option [value]="t">{{ t }}</option> }</select>
          </div>
          <div class="field">
            <label for="st">Status</label>
            <select id="st" class="input" formControlName="status">@for (s of statuses; track s) { <option [value]="s">{{ label(s) }}</option> }</select>
          </div>
          <div class="field">
            <label for="ar">Area (m²)</label>
            <input id="ar" class="input" type="number" formControlName="areaSqMeters" />
            <app-field-error [control]="form.controls.areaSqMeters" />
          </div>
          <div class="field">
            <label for="rt">Monthly rent (ETB)</label>
            <input id="rt" class="input" type="number" formControlName="monthlyRent" />
            <app-field-error [control]="form.controls.monthlyRent" />
          </div>
          <div class="field full">
            <label for="ds">Description</label>
            <textarea id="ds" class="input" formControlName="description"></textarea>
          </div>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn" (click)="closed.emit()">Cancel</button>
          <button type="submit" class="btn primary" [disabled]="saving()">
            @if (saving()) { <span class="spinner"></span> } {{ unit ? 'Save changes' : 'Create unit' }}
          </button>
        </div>
      </form>
    </app-modal>
  `,
})
export class UnitFormComponent implements OnInit {
  @Input() unit: Unit | null = null;
  @Input() defaultFloor = 1;
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  private fb = inject(FormBuilder).nonNullable;
  private svc = inject(UnitsService);
  private toast = inject(ToastService);

  floors = [1, 2, 3, 4, 5, 6, 7];
  types = UNIT_TYPES;
  statuses = UNIT_STATUSES;
  label = label;
  saving = signal(false);

  form = this.fb.group({
    unitNumber: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9-]{2,10}$/)]],
    floorNumber: [1, Validators.required],
    unitType: ['Office' as Unit['unitType'], Validators.required],
    status: ['Available' as Unit['status'], Validators.required],
    areaSqMeters: [50, [Validators.required, Validators.min(1)]],
    monthlyRent: [0, [Validators.required, Validators.min(0)]],
    description: [''],
  });

  ngOnInit() {
    if (this.unit) this.form.patchValue(this.unit);
    else this.form.patchValue({ floorNumber: this.defaultFloor });
  }

  submit() {
    this.form.markAllAsTouched();
    if (this.form.invalid || this.saving()) return;
    this.saving.set(true);
    const v = this.form.getRawValue();
    const req = this.unit ? this.svc.update(this.unit.id, v) : this.svc.create(v);
    req.subscribe({
      next: () => { this.toast.success(this.unit ? 'Unit updated' : 'Unit created'); this.saved.emit(); },
      error: () => this.saving.set(false),
    });
  }
}
