import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { NotificationsService } from '../../core/services/feature-services';
import { IconComponent } from '../../shared/icon.component';
import { ChipComponent, SpinnerComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-notifications-page',
  standalone: true,
  imports: [DatePipe, IconComponent, ChipComponent, SpinnerComponent],
  template: `
    <div class="page" style="max-width:860px">
      <div class="page-header">
        <div>
          <div class="eyebrow">Inbox</div>
          <h1>Notifications</h1>
          <p>{{ svc.unread() }} unread · due dates, overdue invoices, lease and document expiries.</p>
        </div>
        <button class="btn" [disabled]="svc.unread() === 0" (click)="svc.markAllRead().subscribe()"><app-icon name="check" [size]="15" /> Mark all as read</button>
      </div>

      @if (loading()) { <app-spinner /> } @else {
        <div class="card">
          @for (n of svc.items(); track n.id) {
            <button class="item" [class.unread]="!n.isRead" (click)="!n.isRead && svc.markRead(n.id).subscribe()">
              <div class="row-flex"><app-chip [value]="n.notificationType" /><small class="muted">{{ n.createdAt | date: 'MMM d, y · HH:mm' }}</small>
                @if (!n.isRead) { <span class="dot"></span> }</div>
              <b>{{ n.title }}</b>
              <span class="muted">{{ n.message }}</span>
            </button>
          } @empty { <p class="muted" style="text-align:center;padding:40px;margin:0">No notifications.</p> }
        </div>
      }
    </div>
  `,
  styles: [`
    .item{display:flex;flex-direction:column;gap:4px;width:100%;text-align:left;border:0;border-bottom:1px solid var(--line);background:#fff;padding:16px 20px;cursor:pointer;font:inherit}
    .item:last-child{border-bottom:0}.item:hover{background:#f8fafc}.item.unread{background:#f5f8ff}
    .dot{width:8px;height:8px;border-radius:50%;background:var(--primary)}
  `],
})
export class NotificationsPageComponent implements OnInit {
  svc = inject(NotificationsService);
  loading = signal(true);
  ngOnInit() { this.svc.load().subscribe({ next: () => this.loading.set(false), error: () => this.loading.set(false) }); }
}
