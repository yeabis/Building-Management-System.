import { CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DashboardStats } from '../../core/models/models';
import { AuthService } from '../../core/services/auth.service';
import { DashboardService, ReportsService } from '../../core/services/feature-services';
import { BarChartComponent, DonutComponent } from '../../shared/charts.component';
import { IconComponent } from '../../shared/icon.component';
import { SpinnerComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CurrencyPipe, DecimalPipe, DatePipe, RouterLink, IconComponent, BarChartComponent, DonutComponent, SpinnerComponent],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <div class="eyebrow">Owner overview</div>
          <h1>Welcome back, {{ firstName() }}</h1>
          <p>Occupancy, collections and arrears across the Glory Building portfolio.</p>
        </div>
        <div class="actions">
          <a class="btn" routerLink="/units"><app-icon name="building" [size]="16" /> Floor plan</a>
          <a class="btn primary" routerLink="/payments"><app-icon name="wallet" [size]="16" /> Billing &amp; payments</a>
        </div>
      </div>

      @if (!stats()) { <app-spinner /> } @else {
        <div class="grid grid-4">
          <div class="card kpi">
            <div class="label">Occupancy rate <span class="kpi-icon"><app-icon name="building" [size]="16" /></span></div>
            <div class="value">{{ stats()!.occupancyPercent }}%</div>
            <div class="hint">{{ stats()!.totalUnits - stats()!.vacantUnits }} of {{ stats()!.totalUnits }} units counted</div>
          </div>
          <div class="card kpi">
            <div class="label">Total revenue <span class="kpi-icon green"><app-icon name="wallet" [size]="16" /></span></div>
            <div class="value">{{ stats()!.totalRevenue | number: '1.0-0' }}<small>ETB</small></div>
            <div class="hint">All recorded payments</div>
          </div>
          <div class="card kpi alert">
            <div class="label">Outstanding <span class="kpi-icon red"><app-icon name="alert" [size]="16" /></span></div>
            <div class="value">{{ stats()!.outstanding | number: '1.0-0' }}<small>ETB</small></div>
            <div class="hint">Unpaid across open invoices</div>
          </div>
          <div class="card kpi">
            <div class="label">Vacant units <span class="kpi-icon amber"><app-icon name="grid" [size]="16" /></span></div>
            <div class="value">{{ stats()!.vacantUnits }}</div>
            <div class="hint">Available to lease today</div>
          </div>
        </div>

        <div class="grid grid-3-2" style="margin-top:16px">
          <div class="card">
            <div class="card-head"><h3>Revenue: expected vs collected</h3><small>Last 6 months · ETB</small></div>
            <div class="card-pad">
              <app-bar-chart [labels]="months()" [series]="revSeries()" />
            </div>
          </div>
          <div class="card">
            <div class="card-head"><h3>Occupancy</h3><small>By floor</small></div>
            <div class="card-pad occ">
              <app-donut [value]="stats()!.occupancyPercent" />
              <div class="floors">
                @for (f of floorsDesc(); track f.floor) {
                  <div class="frow">
                    <span>L{{ f.floor }}</span>
                    <div class="progress"><span [style.width.%]="(f.occupied / (f.occupied + f.vacant)) * 100"></span></div>
                    <b>{{ f.occupied }}/{{ f.occupied + f.vacant }}</b>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>

        <div class="card" style="margin-top:16px">
          <div class="card-head"><h3>Leases expiring within 30 days</h3>
            <a class="link-btn" routerLink="/reports">Open reports</a>
          </div>
          <div class="table-wrap">
            <table class="table">
              <thead><tr><th>Tenant</th><th>Unit</th><th>Ends</th><th class="num">Days left</th><th class="num">Monthly rent</th></tr></thead>
              <tbody>
                @for (r of expiring(); track $index) {
                  <tr>
                    <td class="cell-main">{{ r['tenantName'] }}</td><td>{{ r['unitNumber'] }}</td>
                    <td>{{ r['endDate'] | date: 'mediumDate' }}</td>
                    <td class="num"><span class="chip" [class.red]="r['daysRemaining'] <= 7" [class.amber]="r['daysRemaining'] > 7">{{ r['daysRemaining'] }} days</span></td>
                    <td class="num">{{ r['monthlyRent'] | currency: 'ETB' : 'code' : '1.0-0' }}</td>
                  </tr>
                } @empty { <tr><td colspan="5" class="empty">No leases expiring soon.</td></tr> }
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .occ{display:flex;gap:20px;align-items:center;flex-wrap:wrap;justify-content:center}
    .floors{flex:1;min-width:150px;display:flex;flex-direction:column;gap:8px}
    .frow{display:grid;grid-template-columns:28px 1fr 36px;gap:8px;align-items:center;font-size:12px}
    .frow b{text-align:right}
  `],
})
export class DashboardComponent implements OnInit {
  private svc = inject(DashboardService);
  private reports = inject(ReportsService);
  auth = inject(AuthService);

  stats = signal<DashboardStats | null>(null);
  expiring = signal<Record<string, any>[]>([]);

  firstName = () => this.auth.user()?.fullName.split(' ')[0] ?? '';
  months = () => this.stats()?.revenueByMonth.map((r) => r.month) ?? [];
  revSeries = () => [
    { name: 'Expected', values: this.stats()?.revenueByMonth.map((r) => r.expected) ?? [], color: '#cbd5e1' },
    { name: 'Collected', values: this.stats()?.revenueByMonth.map((r) => r.collected) ?? [], color: '#1d4ed8' },
  ];
  floorsDesc = () => [...(this.stats()?.occupancyByFloor ?? [])].sort((a, b) => b.floor - a.floor);

  ngOnInit() {
    this.svc.stats().subscribe((s) => this.stats.set(s));
    this.reports.run('lease-expiry', { days: 30 }).subscribe((r) => this.expiring.set(r.rows.slice(0, 6)));
  }
}
