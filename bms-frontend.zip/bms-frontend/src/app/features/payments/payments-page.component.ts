import { CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { Invoice, Payment } from '../../core/models/models';
import { AuthService } from '../../core/services/auth.service';
import { PaymentsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { label, monthName } from '../../core/utils';
import { IconComponent } from '../../shared/icon.component';
import { ChipComponent, PaginationComponent, SpinnerComponent } from '../../shared/ui.components';
import { PaymentFormComponent } from './payment-form.component';

@Component({
  selector: 'app-payments-page',
  standalone: true,
  imports: [CurrencyPipe, DatePipe, DecimalPipe, IconComponent, ChipComponent, PaginationComponent, SpinnerComponent, PaymentFormComponent],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <div class="eyebrow">Financial ledger</div>
          <h1>Billing &amp; Payments</h1>
          <p>Outstanding balances, recorded payments and monthly invoice generation.</p>
        </div>
        <div class="actions">
          @if (auth.canWrite()) {
            <button class="btn" [disabled]="generating()" (click)="generate()">
              @if (generating()) { <span class="spinner" style="border-top-color:var(--primary)"></span> } @else { <app-icon name="refresh" [size]="15" /> } Generate invoices
            </button>
            <button class="btn primary" (click)="openForm(null)"><app-icon name="plus" [size]="16" /> Record payment</button>
          }
        </div>
      </div>

      <div class="tabs" style="margin-bottom:16px">
        <button [class.on]="tab() === 'outstanding'" (click)="setTab('outstanding')">Outstanding balances</button>
        <button [class.on]="tab() === 'history'" (click)="setTab('history')">Payment history</button>
      </div>

      <div class="card">
        @if (tab() === 'outstanding') {
          <div class="table-wrap">
            <table class="table">
              <thead><tr><th>Invoice</th><th>Tenant</th><th>Unit</th><th>Period</th><th>Due</th><th class="num">Amount</th><th class="num">Paid</th><th class="num">Balance</th><th>Status</th><th></th></tr></thead>
              <tbody>
                @if (loading()) { <tr><td colspan="10"><app-spinner /></td></tr> }
                @else {
                  @for (i of invoices(); track i.id) {
                    <tr>
                      <td class="mono cell-main">{{ i.invoiceNumber }}</td><td>{{ i.tenantName }}</td><td>{{ i.unitNumber }}</td>
                      <td>{{ month(i.periodMonth) }} {{ i.periodYear }}</td><td>{{ i.dueDate | date: 'mediumDate' }}</td>
                      <td class="num">{{ i.amountDue | number: '1.0-0' }}</td><td class="num">{{ i.amountPaid | number: '1.0-0' }}</td>
                      <td class="num cell-main">{{ i.balance | number: '1.0-0' }}</td>
                      <td><app-chip [value]="i.status" /></td>
                      <td class="num">@if (auth.canWrite()) { <button class="btn sm" (click)="openForm(i.id)">Record</button> }</td>
                    </tr>
                  } @empty { <tr><td colspan="10" class="empty">No outstanding invoices 🎉</td></tr> }
                }
              </tbody>
            </table>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="table">
              <thead><tr><th>Date</th><th>Invoice</th><th>Tenant</th><th>Method</th><th>Reference</th><th class="num">Amount</th></tr></thead>
              <tbody>
                @if (loading()) { <tr><td colspan="6"><app-spinner /></td></tr> }
                @else {
                  @for (p of payments(); track p.id) {
                    <tr>
                      <td>{{ p.paymentDate | date: 'mediumDate' }}</td><td class="mono">{{ p.invoiceNumber }}</td><td class="cell-main">{{ p.tenantName }}</td>
                      <td><span class="chip">{{ label(p.paymentMethod) }}</span></td><td class="mono">{{ p.referenceNumber }}</td>
                      <td class="num cell-main">{{ p.amountPaid | currency: 'ETB' : 'code' : '1.0-0' }}</td>
                    </tr>
                  } @empty { <tr><td colspan="6" class="empty">No payments recorded yet.</td></tr> }
                }
              </tbody>
            </table>
          </div>
        }
        <app-pagination [page]="page()" [pageSize]="pageSize" [total]="total()" (pageChange)="goTo($event)" />
      </div>
    </div>

    @if (formOpen()) { <app-payment-form [invoiceId]="preselect()" (closed)="formOpen.set(false)" (saved)="formOpen.set(false); load()" /> }
  `,
})
export class PaymentsPageComponent implements OnInit {
  private svc = inject(PaymentsService);
  private toast = inject(ToastService);
  auth = inject(AuthService);

  label = label;
  month = monthName;
  pageSize = 10;
  tab = signal<'outstanding' | 'history'>('outstanding');
  invoices = signal<Invoice[]>([]);
  payments = signal<Payment[]>([]);
  total = signal(0);
  page = signal(1);
  loading = signal(true);
  generating = signal(false);
  formOpen = signal(false);
  preselect = signal<number | null>(null);

  ngOnInit() { this.load(); }

  setTab(t: 'outstanding' | 'history') { this.tab.set(t); this.page.set(1); this.load(); }
  goTo(p: number) { this.page.set(p); this.load(); }
  openForm(id: number | null) { this.preselect.set(id); this.formOpen.set(true); }

  load() {
    this.loading.set(true);
    const q = { page: this.page(), pageSize: this.pageSize };
    if (this.tab() === 'outstanding') {
      this.svc.outstanding(q).subscribe({ next: (r) => { this.invoices.set(r.items); this.total.set(r.totalCount); this.loading.set(false); }, error: () => this.loading.set(false) });
    } else {
      this.svc.history(q).subscribe({ next: (r) => { this.payments.set(r.items); this.total.set(r.totalCount); this.loading.set(false); }, error: () => this.loading.set(false) });
    }
  }

  generate() {
    this.generating.set(true);
    this.svc.generateInvoices().subscribe({
      next: (r) => {
        this.generating.set(false);
        this.toast.success(r.generated ? `${r.generated} invoice(s) generated` : 'All invoices for this period already exist');
        this.load();
      },
      error: () => this.generating.set(false),
    });
  }
}
