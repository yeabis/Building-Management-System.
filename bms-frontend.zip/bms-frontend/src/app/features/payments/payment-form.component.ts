import { CurrencyPipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Invoice, PAYMENT_METHODS } from '../../core/models/models';
import { PaymentsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { label, monthName, today } from '../../core/utils';
import { FieldErrorComponent, ModalComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-payment-form',
  standalone: true,
  imports: [ReactiveFormsModule, CurrencyPipe, ModalComponent, FieldErrorComponent],
  template: `
    <app-modal title="Record payment" [width]="620" (closed)="closed.emit()">
      <form [formGroup]="form" (ngSubmit)="submit()" novalidate>
        <div class="field">
          <label for="inv">Invoice</label>
          <select id="inv" class="input" formControlName="invoiceId" (change)="onInvoice()">
            <option [ngValue]="null" disabled>Select an open invoice…</option>
            @for (i of invoices(); track i.id) {
              <option [ngValue]="i.id">{{ i.invoiceNumber }} · {{ i.tenantName }} · {{ i.unitNumber }}</option>
            }
          </select>
          <app-field-error [control]="form.controls.invoiceId" />
        </div>

        @if (selected(); as inv) {
          <div class="summary">
            <div><small>Period</small><b>{{ month(inv.periodMonth) }} {{ inv.periodYear }}</b></div>
            <div><small>Invoice total</small><b>{{ inv.amountDue | currency: 'ETB' : 'code' : '1.0-0' }}</b></div>
            <div><small>Already paid</small><b>{{ inv.amountPaid | currency: 'ETB' : 'code' : '1.0-0' }}</b></div>
            <div><small>Balance due</small><b class="due">{{ inv.balance | currency: 'ETB' : 'code' : '1.0-0' }}</b></div>
          </div>
        }

        <div class="form-grid">
          <div class="field">
            <label for="am">Amount paid (ETB)</label>
            <input id="am" class="input" type="number" formControlName="amountPaid" />
            <app-field-error [control]="form.controls.amountPaid" />
            @if (overBalance()) { <small class="err">Amount exceeds the outstanding balance.</small> }
            @else if (selected() && form.controls.amountPaid.value < selected()!.balance && form.controls.amountPaid.value > 0) { <small class="muted">Partial payment — the invoice stays open.</small> }
          </div>
          <div class="field">
            <label for="pd">Payment date</label>
            <input id="pd" class="input" type="date" formControlName="paymentDate" />
            <app-field-error [control]="form.controls.paymentDate" />
          </div>
          <div class="field">
            <label for="pm">Method</label>
            <select id="pm" class="input" formControlName="paymentMethod">@for (m of methods; track m) { <option [value]="m">{{ label(m) }}</option> }</select>
          </div>
          <div class="field">
            <label for="rf">Reference number</label>
            <input id="rf" class="input" formControlName="referenceNumber" placeholder="Bank / Telebirr ref" />
            <app-field-error [control]="form.controls.referenceNumber" />
          </div>
          <div class="field full">
            <label for="nt">Notes (optional)</label>
            <textarea id="nt" class="input" formControlName="notes"></textarea>
          </div>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn" (click)="closed.emit()">Cancel</button>
          <button type="submit" class="btn primary" [disabled]="saving()">@if (saving()) { <span class="spinner"></span> } Record payment</button>
        </div>
      </form>
    </app-modal>
  `,
  styles: [`
    .summary{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;background:var(--soft);border-radius:10px;padding:12px 14px;margin-bottom:16px}
    .summary small{display:block;color:var(--muted);font-size:11px}.summary b{font-size:13px}.due{color:var(--red)}
    @media (max-width:560px){.summary{grid-template-columns:1fr 1fr}}
  `],
})
export class PaymentFormComponent implements OnInit {
  /** Optionally pre-select an invoice (when opened from a table row). */
  @Input() invoiceId: number | null = null;
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  private fb = inject(FormBuilder);
  private svc = inject(PaymentsService);
  private toast = inject(ToastService);

  methods = PAYMENT_METHODS;
  label = label;
  month = monthName;
  invoices = signal<Invoice[]>([]);
  selected = signal<Invoice | null>(null);
  saving = signal(false);

  form = this.fb.group({
    invoiceId: this.fb.control<number | null>(null, Validators.required),
    amountPaid: this.fb.nonNullable.control(0, [Validators.required, Validators.min(1)]),
    paymentDate: this.fb.nonNullable.control(today(), Validators.required),
    paymentMethod: this.fb.nonNullable.control('BankTransfer' as (typeof PAYMENT_METHODS)[number], Validators.required),
    referenceNumber: this.fb.nonNullable.control('', [Validators.required, Validators.minLength(3)]),
    notes: this.fb.nonNullable.control(''),
  });

  ngOnInit() {
    this.svc.outstanding({ page: 1, pageSize: 200 }).subscribe((r) => {
      this.invoices.set(r.items);
      if (this.invoiceId) { this.form.controls.invoiceId.setValue(this.invoiceId); this.onInvoice(); }
    });
  }

  overBalance() {
    const s = this.selected();
    return !!s && this.form.controls.amountPaid.value > s.balance;
  }

  onInvoice() {
    const inv = this.invoices().find((i) => i.id === this.form.controls.invoiceId.value) ?? null;
    this.selected.set(inv);
    if (inv) this.form.controls.amountPaid.setValue(inv.balance);
  }

  submit() {
    this.form.markAllAsTouched();
    if (this.form.invalid || this.overBalance() || this.saving()) return;
    this.saving.set(true);
    const v = this.form.getRawValue();
    this.svc.record({ ...v, invoiceId: v.invoiceId! }).subscribe({
      next: () => { this.toast.success('Payment recorded'); this.saved.emit(); },
      error: () => this.saving.set(false),
    });
  }
}
