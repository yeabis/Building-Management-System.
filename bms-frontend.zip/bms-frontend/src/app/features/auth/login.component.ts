import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { IconComponent } from '../../shared/icon.component';
import { FieldErrorComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, FieldErrorComponent, IconComponent],
  template: `
    <div class="login">
      <section class="hero">
        <div class="brand"><span class="logo"><app-icon name="building" /></span><b>Glory Building</b><span class="tag">Commercial</span></div>
        <div class="copy">
          <h1>Integrated facility operations, leasing &amp; verified transactions.</h1>
          <p>Centralized building intelligence for facility managers, real-time 7-floor occupancy tracking, and automated rent reconciliation.</p>
          <div class="stats">
            <div><b>7 Floors</b><small>42 rentable units</small></div>
            <div><b>91.3%</b><small>Occupancy</small></div>
            <div><b>Monthly</b><small>Auto invoicing</small></div>
          </div>
        </div>
        <small class="foot">Building Management System · v1.0</small>
      </section>

      <section class="panel">
        <form class="box" [formGroup]="form" (ngSubmit)="submit()" novalidate>
          <span class="chip blue">Administrative Access Portal</span>
          <h2>Welcome Back</h2>
          <p class="muted">Please enter your details to sign in.</p>

          @if (error()) { <div class="form-error">{{ error() }}</div> }

          <div class="field">
            <label for="email">Email address</label>
            <input id="email" class="input" type="email" formControlName="email" placeholder="admin&#64;glory.et" autocomplete="username" />
            <app-field-error [control]="form.controls.email" />
          </div>
          <div class="field">
            <label for="pw">Password</label>
            <input id="pw" class="input" type="password" formControlName="password" placeholder="••••••••" autocomplete="current-password" />
            <app-field-error [control]="form.controls.password" />
          </div>
          <label class="remember"><input type="checkbox" formControlName="remember" /> Remember for 30 days</label>

          <button class="btn primary block" type="submit" [disabled]="loading()">
            @if (loading()) { <span class="spinner"></span> } Sign in to portal <app-icon name="arrow" [size]="16" />
          </button>

          <div class="hint">
            <b>Demo accounts</b>
            <button type="button" class="link-btn" (click)="fill('admin&#64;glory.et','Admin&#64;123')">Admin</button>
            <button type="button" class="link-btn" (click)="fill('manager&#64;glory.et','Manager&#64;123')">Manager</button>
            <button type="button" class="link-btn" (click)="fill('viewer&#64;glory.et','Viewer&#64;123')">Viewer</button>
          </div>
        </form>
      </section>
    </div>
  `,
  styles: [`
    .login{display:grid;grid-template-columns:1.1fr 1fr;min-height:100vh}
    .hero{background:radial-gradient(1200px 600px at 20% 0%,#16254a 0%,#0b1226 60%);color:#fff;padding:36px 48px;display:flex;flex-direction:column;justify-content:space-between}
    .brand{display:flex;align-items:center;gap:10px}
    .logo{width:34px;height:34px;border-radius:9px;background:#fff;color:var(--ink);display:grid;place-items:center}
    .tag{font-size:11px;background:rgba(255,255,255,.14);padding:3px 9px;border-radius:99px}
    .copy{max-width:520px}
    h1{font-family:var(--serif);font-size:44px;line-height:1.1;font-weight:500;margin:0 0 18px}
    .copy p{color:#b7c0d6;line-height:1.6}
    .stats{display:flex;gap:36px;margin-top:34px;padding-top:22px;border-top:1px solid rgba(255,255,255,.14)}
    .stats b{display:block;font-size:20px}.stats small{color:#93a0bd}
    .foot{color:#6b7a99}
    .panel{background:#fff;display:grid;place-items:center;padding:32px}
    .box{width:100%;max-width:380px}
    h2{font-size:28px;margin:14px 0 4px}
    .box .muted{margin:0 0 22px}
    .remember{display:flex;gap:8px;align-items:center;margin:4px 0 18px;font-size:13px;color:var(--ink-2)}
    .hint{display:flex;gap:12px;align-items:center;margin-top:22px;padding-top:16px;border-top:1px solid var(--line);font-size:12px;color:var(--muted)}
    @media (max-width:900px){.login{grid-template-columns:1fr}.hero{display:none}}
  `],
})
export class LoginComponent {
  private fb = inject(FormBuilder).nonNullable;
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  loading = signal(false);
  error = signal('');
  form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    remember: [true],
  });

  fill(email: string, password: string) { this.form.patchValue({ email, password }); }

  submit() {
    this.form.markAllAsTouched();
    if (this.form.invalid || this.loading()) return;
    this.loading.set(true);
    this.error.set('');
    const { email, password, remember } = this.form.getRawValue();
    this.auth.login(email, password, remember).subscribe({
      next: () => this.router.navigateByUrl(this.route.snapshot.queryParamMap.get('returnUrl') ?? '/dashboard'),
      error: (e) => { this.loading.set(false); this.error.set(e.error?.message ?? 'Unable to sign in.'); },
    });
  }
}
