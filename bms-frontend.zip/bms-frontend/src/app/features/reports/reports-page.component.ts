import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { environment } from '../../../environments/environment';
import { ReportResult, ReportType } from '../../core/models/models';
import { ReportsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { label, saveBlob } from '../../core/utils';
import { BarChartComponent, DonutComponent } from '../../shared/charts.component';
import { IconComponent } from '../../shared/icon.component';
import { SpinnerComponent } from '../../shared/ui.components';

interface Col { key: string; label: string; kind?: 'num' | 'money' | 'date' | 'pct' | 'text' }
interface Def { type: ReportType; title: string; blurb: string; cols: Col[]; filter?: 'year' | 'days' }

const DEFS: Def[] = [
  { type: 'occupancy', title: 'Occupancy', blurb: 'Units occupied vs vacant per floor and overall.', cols: [
    { key: 'floor', label: 'Floor' }, { key: 'totalUnits', label: 'Units', kind: 'num' }, { key: 'occupied', label: 'Occupied', kind: 'num' },
    { key: 'vacant', label: 'Vacant', kind: 'num' }, { key: 'occupancyPercent', label: 'Occupancy', kind: 'pct' } ] },
  { type: 'revenue', title: 'Revenue', blurb: 'Rent collected vs expected, monthly and year-to-date.', filter: 'year', cols: [
    { key: 'month', label: 'Month' }, { key: 'expected', label: 'Expected (ETB)', kind: 'money' }, { key: 'collected', label: 'Collected (ETB)', kind: 'money' },
    { key: 'collectionRate', label: 'Collection rate', kind: 'pct' } ] },
  { type: 'arrears', title: 'Arrears', blurb: 'Tenants with overdue balances, months overdue and total owed.', cols: [
    { key: 'tenantName', label: 'Tenant' }, { key: 'unitNumber', label: 'Unit' }, { key: 'monthsOverdue', label: 'Months overdue', kind: 'num' }, { key: 'totalOwed', label: 'Total owed (ETB)', kind: 'money' } ] },
  { type: 'lease-expiry', title: 'Lease expiry', blurb: 'Leases ending within the chosen number of days.', filter: 'days', cols: [
    { key: 'tenantName', label: 'Tenant' }, { key: 'unitNumber', label: 'Unit' }, { key: 'endDate', label: 'Ends', kind: 'date' }, { key: 'daysRemaining', label: 'Days left', kind: 'num' }, { key: 'monthlyRent', label: 'Monthly rent (ETB)', kind: 'money' } ] },
  { type: 'document-expiry', title: 'Document expiry', blurb: 'Legal documents expiring within 30 days.', cols: [
    { key: 'tenantName', label: 'Tenant' }, { key: 'documentType', label: 'Document' }, { key: 'expiryDate', label: 'Expires', kind: 'date' }, { key: 'daysRemaining', label: 'Days left', kind: 'num' } ] },
];

@Component({
  selector: 'app-reports-page',
  standalone: true,
  imports: [ReactiveFormsModule, DatePipe, DecimalPipe, IconComponent, SpinnerComponent, BarChartComponent, DonutComponent],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <div class="eyebrow">Analytics</div>
          <h1>Reports</h1>
          <p>{{ def().blurb }}</p>
        </div>
        <button class="btn dark" [disabled]="exporting() || !result()?.rows?.length" (click)="export()">
          @if (exporting()) { <span class="spinner"></span> } @else { <app-icon name="download" [size]="15" /> } Export to Excel
        </button>
      </div>

      <div class="tabs" style="margin-bottom:16px;flex-wrap:wrap">
        @for (d of defs; track d.type) { <button [class.on]="d.type === type()" (click)="select(d.type)">{{ d.title }}</button> }
      </div>

      @if (def().filter) {
        <form class="card card-pad filter" [formGroup]="filters" (ngSubmit)="run()">
          @if (def().filter === 'year') {
            <div class="field"><label for="yr">Year</label><select id="yr" class="input" formControlName="year">@for (y of years; track y) { <option [value]="y">{{ y }}</option> }</select></div>
          } @else {
            <div class="field"><label for="dy">Expiring within (days)</label><input id="dy" class="input" type="number" min="1" max="365" formControlName="days" /></div>
          }
          <button class="btn primary" type="submit" style="margin-bottom:14px">Apply</button>
        </form>
      }

      @if (loading()) { <app-spinner /> } @else if (result(); as r) {
        <div class="grid grid-4" style="margin-bottom:16px">
          @for (s of r.summary; track s.label) {
            <div class="card kpi"><div class="label">{{ s.label }}</div><div class="value">{{ fmtSummary(s.value) }}</div></div>
          }
        </div>

        @if (type() === 'revenue' && r.rows.length) {
          <div class="card" style="margin-bottom:16px">
            <div class="card-head"><h3>Expected vs collected</h3><small>ETB</small></div>
            <div class="card-pad"><app-bar-chart [labels]="chartLabels()" [series]="revenueSeries()" /></div>
          </div>
        }
        @if (type() === 'occupancy' && r.rows.length) {
          <div class="grid grid-3-2" style="margin-bottom:16px">
            <div class="card"><div class="card-head"><h3>Occupied vs vacant by floor</h3></div><div class="card-pad"><app-bar-chart [labels]="chartLabels()" [series]="occupancySeries()" /></div></div>
            <div class="card"><div class="card-head"><h3>Overall</h3></div><div class="card-pad" style="display:grid;place-items:center"><app-donut [value]="overall()" /></div></div>
          </div>
        }

        <div class="card">
          <div class="table-wrap">
            <table class="table">
              <thead><tr>@for (c of def().cols; track c.key) { <th [class.num]="c.kind === 'num' || c.kind === 'money' || c.kind === 'pct'">{{ c.label }}</th> }</tr></thead>
              <tbody>
                @for (row of r.rows; track $index) {
                  <tr>
                    @for (c of def().cols; track c.key) {
                      <td [class.num]="c.kind === 'num' || c.kind === 'money' || c.kind === 'pct'">
                        @switch (c.kind) {
                          @case ('money') { {{ row[c.key] | number: '1.0-0' }} }
                          @case ('pct') { {{ row[c.key] }}% }
                          @case ('date') { {{ row[c.key] | date: 'mediumDate' }} }
                          @default { {{ c.key === 'documentType' ? label(row[c.key]) : row[c.key] }} }
                        }
                      </td>
                    }
                  </tr>
                } @empty { <tr><td [attr.colspan]="def().cols.length" class="empty">Nothing to report for these filters.</td></tr> }
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`.filter{display:flex;gap:12px;align-items:flex-end;margin-bottom:16px;padding-bottom:6px}.filter .field{margin-bottom:14px;width:200px}`],
})
export class ReportsPageComponent implements OnInit {
  private svc = inject(ReportsService);
  private fb = inject(FormBuilder).nonNullable;
  private toast = inject(ToastService);

  defs = DEFS;
  label = label;
  years = [0, 1, 2].map((i) => new Date().getFullYear() - i);
  type = signal<ReportType>('occupancy');
  def = computed(() => DEFS.find((d) => d.type === this.type())!);
  result = signal<ReportResult | null>(null);
  loading = signal(true);
  exporting = signal(false);
  filters = this.fb.group({ year: [new Date().getFullYear()], days: [30] });

  chartLabels = () => (this.result()?.rows ?? []).map((r) => String(r['floor'] ?? r['month']).replace('Floor ', 'L'));
  revenueSeries = () => [
    { name: 'Expected', values: (this.result()?.rows ?? []).map((r) => r['expected']), color: '#cbd5e1' },
    { name: 'Collected', values: (this.result()?.rows ?? []).map((r) => r['collected']), color: '#1d4ed8' },
  ];
  occupancySeries = () => [
    { name: 'Occupied', values: (this.result()?.rows ?? []).map((r) => r['occupied']), color: '#22c55e' },
    { name: 'Vacant', values: (this.result()?.rows ?? []).map((r) => r['vacant']), color: '#cbd5e1' },
  ];
  overall = () => {
    const rows = this.result()?.rows ?? [];
    const total = rows.reduce((s, r) => s + r['totalUnits'], 0);
    return total ? Math.round((rows.reduce((s, r) => s + r['occupied'], 0) / total) * 100) : 0;
  };
  fmtSummary = (v: string | number) => (typeof v === 'number' && v >= 1000 ? v.toLocaleString() : v);

  ngOnInit() { this.run(); }

  select(t: ReportType) { this.type.set(t); this.run(); }

  private query() {
    const v = this.filters.getRawValue();
    const f = this.def().filter;
    return f === 'year' ? { year: v.year } : f === 'days' ? { days: v.days } : {};
  }

  run() {
    this.loading.set(true);
    this.svc.run(this.type(), this.query()).subscribe({
      next: (r) => { this.result.set(r); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  export() {
    this.exporting.set(true);
    this.svc.export(this.type(), this.query()).subscribe({
      next: (blob) => {
        // The mock backend returns CSV; the real API returns an .xlsx file.
        saveBlob(blob, `${this.type()}-report.${environment.useMock ? 'csv' : 'xlsx'}`);
        this.exporting.set(false);
        this.toast.success('Report exported');
      },
      error: () => this.exporting.set(false),
    });
  }
}
