import { Component, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { debounceTime } from 'rxjs';
import { BUSINESS_TYPES, Tenant } from '../../core/models/models';
import { AuthService } from '../../core/services/auth.service';
import { TenantsService } from '../../core/services/feature-services';
import { initials } from '../../core/utils';
import { IconComponent } from '../../shared/icon.component';
import { ChipComponent, PaginationComponent, SpinnerComponent } from '../../shared/ui.components';
import { TenantFormComponent } from './tenant-form.component';

@Component({
  selector: 'app-tenants-list',
  standalone: true,
  imports: [ReactiveFormsModule, IconComponent, ChipComponent, PaginationComponent, SpinnerComponent, TenantFormComponent],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <div class="eyebrow">Tenant registry</div>
          <h1>Tenants Directory</h1>
          <p>Every organization renting space in the building.</p>
        </div>
        @if (auth.canWrite()) {
          <button class="btn primary" (click)="formOpen.set(true)"><app-icon name="plus" [size]="16" /> Register tenant</button>
        }
      </div>

      <div class="card">
        <form class="toolbar" [formGroup]="filters">
          <div class="search"><app-icon name="search" [size]="16" /><input class="input" formControlName="search" placeholder="Search by name, TIN or business type" /></div>
          <select class="input" formControlName="businessType"><option value="">All business types</option>@for (b of types; track b) { <option [value]="b">{{ b }}</option> }</select>
          <select class="input" formControlName="isActive"><option value="">All statuses</option><option value="true">Active</option><option value="false">Inactive</option></select>
        </form>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Organization</th><th>Contact person</th><th>Phone</th><th>TIN</th><th>Business</th><th>Units</th><th>Status</th></tr></thead>
            <tbody>
              @if (loading()) { <tr><td colspan="7"><app-spinner /></td></tr> }
              @else {
                @for (t of rows(); track t.id) {
                  <tr class="clickable" (click)="open(t)">
                    <td><div class="row-flex"><span class="avatar">{{ ini(t.organizationName) }}</span><div><div class="cell-main">{{ t.organizationName }}</div><div class="cell-sub">{{ t.contactEmail }}</div></div></div></td>
                    <td>{{ t.contactPersonName }}</td><td class="mono">{{ t.phone }}</td><td class="mono">{{ t.tinNumber }}</td>
                    <td>{{ t.businessType }}</td>
                    <td>{{ t.activeUnits.join(', ') || '—' }}</td>
                    <td><app-chip [value]="t.isActive ? 'Active' : 'Inactive'" /></td>
                  </tr>
                } @empty { <tr><td colspan="7" class="empty">No tenants found.</td></tr> }
              }
            </tbody>
          </table>
        </div>
        <app-pagination [page]="page()" [pageSize]="pageSize" [total]="total()" (pageChange)="goTo($event)" />
      </div>
    </div>

    @if (formOpen()) { <app-tenant-form (closed)="formOpen.set(false)" (saved)="formOpen.set(false); load()" /> }
  `,
})
export class TenantsListComponent implements OnInit {
  private svc = inject(TenantsService);
  private fb = inject(FormBuilder).nonNullable;
  private router = inject(Router);
  auth = inject(AuthService);

  types = BUSINESS_TYPES;
  pageSize = 10;
  rows = signal<Tenant[]>([]);
  total = signal(0);
  page = signal(1);
  loading = signal(true);
  formOpen = signal(false);
  ini = initials;
  filters = this.fb.group({ search: [''], businessType: [''], isActive: [''] });

  ngOnInit() {
    this.load();
    this.filters.valueChanges.pipe(debounceTime(300)).subscribe(() => { this.page.set(1); this.load(); });
  }

  load() {
    this.loading.set(true);
    this.svc.list({ ...this.filters.getRawValue(), page: this.page(), pageSize: this.pageSize }).subscribe({
      next: (r) => { this.rows.set(r.items); this.total.set(r.totalCount); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
  goTo(p: number) { this.page.set(p); this.load(); }
  open(t: Tenant) { this.router.navigate(['/tenants', t.id]); }
}
