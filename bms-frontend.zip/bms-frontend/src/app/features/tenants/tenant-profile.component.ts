import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, Input, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { DOCUMENT_TYPES, Lease, Tenant } from '../../core/models/models';
import { AuthService } from '../../core/services/auth.service';
import { LeasesService, TenantsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { daysUntil, initials, label } from '../../core/utils';
import { IconComponent } from '../../shared/icon.component';
import { ChipComponent, FieldErrorComponent, SpinnerComponent } from '../../shared/ui.components';
import { TenantFormComponent } from './tenant-form.component';

@Component({
  selector: 'app-tenant-profile',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink, DatePipe, CurrencyPipe, IconComponent, ChipComponent, FieldErrorComponent, SpinnerComponent, TenantFormComponent],
  template: `
    <div class="page">
      <a routerLink="/tenants" class="link-btn">← Back to directory</a>
      @if (!tenant()) { <app-spinner /> } @else {
        @let t = tenant()!;
        <div class="page-header" style="margin-top:12px">
          <div class="row-flex">
            <span class="avatar big">{{ ini(t.organizationName) }}</span>
            <div>
              <h1>{{ t.organizationName }}</h1>
              <p><app-chip [value]="t.isActive ? 'Active' : 'Inactive'" /> &nbsp; {{ t.businessType }} · TIN {{ t.tinNumber }}</p>
            </div>
          </div>
          @if (auth.canWrite()) {
            <div class="actions">
              <button class="btn" (click)="editOpen.set(true)"><app-icon name="edit" [size]="15" /> Edit</button>
              @if (t.isActive) { <button class="btn danger" [disabled]="busy()" (click)="deactivate()">Deactivate</button> }
            </div>
          }
        </div>

        <div class="grid grid-3-2">
          <div class="card">
            <div class="card-head"><h3>Legal documents</h3><small>{{ t.documents?.length ?? 0 }} on file</small></div>
            <div class="table-wrap">
              <table class="table">
                <thead><tr><th>Type</th><th>File</th><th>Expires</th><th>Status</th></tr></thead>
                <tbody>
                  @for (d of t.documents; track d.id) {
                    <tr>
                      <td class="cell-main">{{ label(d.documentType) }}</td>
                      <td class="cell-sub">{{ d.fileName }}</td>
                      <td>
                        {{ d.expiryDate ? (d.expiryDate | date: 'mediumDate') : '—' }}
                        @if (expiring(d.expiryDate)) { <span class="chip red">Expiring soon</span> }
                      </td>
                      <td><app-chip [value]="d.isVerified ? 'Verified' : 'Pending'" /></td>
                    </tr>
                  } @empty { <tr><td colspan="4" class="empty">No documents uploaded.</td></tr> }
                </tbody>
              </table>
            </div>

            @if (auth.canWrite()) {
              <form class="upload" [formGroup]="docForm" (ngSubmit)="upload()" novalidate>
                <h4>Upload document</h4>
                <div class="form-grid">
                  <div class="field">
                    <label for="dt">Document type</label>
                    <select id="dt" class="input" formControlName="documentType">@for (d of docTypes; track d) { <option [value]="d">{{ label(d) }}</option> }</select>
                  </div>
                  <div class="field">
                    <label for="ex">Expiry date</label>
                    <input id="ex" class="input" type="date" formControlName="expiryDate" />
                    <app-field-error [control]="docForm.controls.expiryDate" />
                  </div>
                  <div class="field full">
                    <label for="fi">File (PDF or image, max 5 MB)</label>
                    <input id="fi" class="input file" type="file" accept=".pdf,.png,.jpg,.jpeg" (change)="onFile($event)" />
                    @if (fileError()) { <small class="err">{{ fileError() }}</small> }
                  </div>
                </div>
                <button class="btn primary" type="submit" [disabled]="uploading()">
                  @if (uploading()) { <span class="spinner"></span> } @else { <app-icon name="upload" [size]="15" /> } Upload
                </button>
              </form>
            }
          </div>

          <div class="side">
            <div class="card card-pad">
              <h3>Contact</h3>
              <dl class="kv" style="margin-top:14px">
                <dt>Contact person</dt><dd>{{ t.contactPersonName }}</dd>
                <dt>Email</dt><dd>{{ t.contactEmail }}</dd>
                <dt>Phone</dt><dd>{{ t.phone }}</dd>
                <dt>Active units</dt><dd>{{ t.activeUnits.join(', ') || '—' }}</dd>
              </dl>
            </div>
            <div class="card">
              <div class="card-head"><h3>Lease history</h3></div>
              <div class="table-wrap">
                <table class="table">
                  <thead><tr><th>Unit</th><th>Period</th><th>Status</th></tr></thead>
                  <tbody>
                    @for (l of leases(); track l.id) {
                      <tr>
                        <td class="cell-main">{{ l.unitNumber }}<div class="cell-sub">{{ l.monthlyRent | currency: 'ETB' : 'code' : '1.0-0' }}/mo</div></td>
                        <td class="cell-sub">{{ l.startDate | date: 'MMM y' }} – {{ l.endDate | date: 'MMM y' }}</td>
                        <td><app-chip [value]="l.status" /></td>
                      </tr>
                    } @empty { <tr><td colspan="3" class="empty">No leases yet.</td></tr> }
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      }
    </div>
    @if (editOpen() && tenant()) { <app-tenant-form [tenant]="tenant()" (closed)="editOpen.set(false)" (saved)="editOpen.set(false); load()" /> }
  `,
  styles: [`
    .avatar.big{width:52px;height:52px;border-radius:14px;font-size:16px}
    .side{display:flex;flex-direction:column;gap:16px}
    .upload{padding:20px;border-top:1px solid var(--line)}
    .upload h4{margin-bottom:12px}
    .input.file{padding:6px 8px;height:auto}
  `],
})
export class TenantProfileComponent implements OnInit {
  /** Bound from the :id route param (withComponentInputBinding). */
  @Input() id!: string;

  private svc = inject(TenantsService);
  private leasesSvc = inject(LeasesService);
  private fb = inject(FormBuilder).nonNullable;
  private toast = inject(ToastService);
  private router = inject(Router);
  auth = inject(AuthService);

  tenant = signal<Tenant | null>(null);
  leases = signal<Lease[]>([]);
  editOpen = signal(false);
  busy = signal(false);
  uploading = signal(false);
  fileError = signal('');
  file: File | null = null;

  ini = initials;
  label = label;
  docTypes = DOCUMENT_TYPES;
  docForm = this.fb.group({ documentType: ['BusinessLicense'], expiryDate: ['', Validators.required] });

  ngOnInit() { this.load(); }

  load() {
    this.svc.get(+this.id).subscribe((t) => this.tenant.set(t));
    this.leasesSvc.list({ tenantId: this.id, page: 1, pageSize: 50 }).subscribe((r) => this.leases.set(r.items));
  }

  expiring(date: string | null) { const d = daysUntil(date); return d !== null && d <= 30; }

  onFile(e: Event) {
    const f = (e.target as HTMLInputElement).files?.[0] ?? null;
    this.fileError.set('');
    this.file = null;
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) { this.fileError.set('File is larger than 5 MB.'); return; }
    this.file = f;
  }

  upload() {
    this.docForm.markAllAsTouched();
    if (!this.file) this.fileError.set('Please choose a file.');
    if (this.docForm.invalid || !this.file || this.uploading()) return;
    this.uploading.set(true);
    const fd = new FormData();
    fd.append('file', this.file);
    fd.append('documentType', this.docForm.controls.documentType.value);
    fd.append('expiryDate', this.docForm.controls.expiryDate.value);
    this.svc.uploadDocument(+this.id, fd).subscribe({
      next: () => { this.toast.success('Document uploaded'); this.uploading.set(false); this.file = null; this.docForm.reset({ documentType: 'BusinessLicense', expiryDate: '' }); this.load(); },
      error: () => this.uploading.set(false),
    });
  }

  deactivate() {
    if (!confirm('Deactivate this tenant? They will no longer be available for new leases.')) return;
    this.busy.set(true);
    this.svc.deactivate(+this.id).subscribe({
      next: () => { this.toast.success('Tenant deactivated'); this.busy.set(false); this.load(); },
      error: () => this.busy.set(false),
    });
  }
}
