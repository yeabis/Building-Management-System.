import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { BUSINESS_TYPES, Tenant } from '../../core/models/models';
import { TenantsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { FieldErrorComponent, ModalComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-tenant-form',
  standalone: true,
  imports: [ReactiveFormsModule, ModalComponent, FieldErrorComponent],
  template: `
    <app-modal [title]="tenant ? 'Edit tenant' : 'Register tenant'" [width]="620" (closed)="closed.emit()">
      <form [formGroup]="form" (ngSubmit)="submit()" novalidate>
        <div class="form-grid">
          <div class="field full">
            <label for="on">Organization name</label>
            <input id="on" class="input" formControlName="organizationName" />
            <app-field-error [control]="form.controls.organizationName" />
          </div>
          <div class="field">
            <label for="tin">TIN number</label>
            <input id="tin" class="input" formControlName="tinNumber" placeholder="10 digits" />
            <app-field-error [control]="form.controls.tinNumber" patternMessage="TIN must be exactly 10 digits" />
          </div>
          <div class="field">
            <label for="ph">Phone</label>
            <input id="ph" class="input" formControlName="phone" placeholder="+251911000000" />
            <app-field-error [control]="form.controls.phone" patternMessage="Enter a valid phone number" />
          </div>
          <div class="field">
            <label for="bt">Business type</label>
            <select id="bt" class="input" formControlName="businessType">@for (b of types; track b) { <option [value]="b">{{ b }}</option> }</select>
          </div>
          <div class="field">
            <label for="cp">Contact person</label>
            <input id="cp" class="input" formControlName="contactPersonName" />
            <app-field-error [control]="form.controls.contactPersonName" />
          </div>
          <div class="field full">
            <label for="em">Contact email</label>
            <input id="em" class="input" type="email" formControlName="contactEmail" />
            <app-field-error [control]="form.controls.contactEmail" />
          </div>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn" (click)="closed.emit()">Cancel</button>
          <button type="submit" class="btn primary" [disabled]="saving()">
            @if (saving()) { <span class="spinner"></span> } {{ tenant ? 'Save changes' : 'Register tenant' }}
          </button>
        </div>
      </form>
    </app-modal>
  `,
})
export class TenantFormComponent implements OnInit {
  @Input() tenant: Tenant | null = null;
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  private fb = inject(FormBuilder).nonNullable;
  private svc = inject(TenantsService);
  private toast = inject(ToastService);
  types = BUSINESS_TYPES;
  saving = signal(false);

  form = this.fb.group({
    organizationName: ['', [Validators.required, Validators.minLength(2)]],
    tinNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    phone: ['', [Validators.required, Validators.pattern(/^\+?[0-9\s-]{7,15}$/)]],
    businessType: ['Services' as Tenant['businessType'], Validators.required],
    contactPersonName: ['', Validators.required],
    contactEmail: ['', [Validators.required, Validators.email]],
  });

  ngOnInit() { if (this.tenant) this.form.patchValue(this.tenant); }

  submit() {
    this.form.markAllAsTouched();
    if (this.form.invalid || this.saving()) return;
    this.saving.set(true);
    const v = this.form.getRawValue();
    (this.tenant ? this.svc.update(this.tenant.id, v) : this.svc.create(v)).subscribe({
      next: () => { this.toast.success(this.tenant ? 'Tenant updated' : 'Tenant registered'); this.saved.emit(); },
      error: () => this.saving.set(false),
    });
  }
}
