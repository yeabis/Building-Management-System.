import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LEASE_STATUSES, Lease } from '../../core/models/models';
import { AuthService } from '../../core/services/auth.service';
import { LeasesService } from '../../core/services/feature-services';
import { daysUntil, label } from '../../core/utils';
import { IconComponent } from '../../shared/icon.component';
import { ChipComponent, PaginationComponent, SpinnerComponent } from '../../shared/ui.components';
import { LeaseActionComponent } from './lease-action.component';
import { LeaseFormComponent } from './lease-form.component';

@Component({
  selector: 'app-leases-page',
  standalone: true,
  imports: [ReactiveFormsModule, CurrencyPipe, DatePipe, IconComponent, ChipComponent, PaginationComponent, SpinnerComponent, LeaseFormComponent, LeaseActionComponent],
  template: `
    <div class="page">
      <div class="page-header">
        <div>
          <div class="eyebrow">Institutional portfolio</div>
          <h1>Lease Agreements</h1>
          <p>Create, renew and terminate commercial leases.
            @if (unitFilter || tenantFilter) { <button class="link-btn" (click)="clearHistory()">Showing filtered history · clear</button> }
          </p>
        </div>
        @if (auth.canWrite()) {
          <button class="btn primary" (click)="createOpen.set(true)"><app-icon name="plus" [size]="16" /> Create lease</button>
        }
      </div>

      <div class="card">
        <form class="toolbar" [formGroup]="filters">
          <select class="input" formControlName="status"><option value="">All statuses</option>@for (s of statuses; track s) { <option [value]="s">{{ label(s) }}</option> }</select>
        </form>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Tenant</th><th>Unit</th><th>Start</th><th>End</th><th class="num">Monthly rent</th><th class="num">Deposit</th><th>Status</th><th></th></tr></thead>
            <tbody>
              @if (loading()) { <tr><td colspan="8"><app-spinner /></td></tr> }
              @else {
                @for (l of rows(); track l.id) {
                  <tr>
                    <td class="cell-main">{{ l.tenantName }}</td>
                    <td>{{ l.unitNumber }}</td>
                    <td>{{ l.startDate | date: 'mediumDate' }}</td>
                    <td>{{ l.endDate | date: 'mediumDate' }}
                      @if (l.status === 'Active' && soon(l.endDate)) { <span class="chip amber">Ending soon</span> }
                    </td>
                    <td class="num">{{ l.monthlyRent | currency: 'ETB' : 'code' : '1.0-0' }}</td>
                    <td class="num">{{ l.depositAmount | currency: 'ETB' : 'code' : '1.0-0' }}</td>
                    <td><app-chip [value]="l.status" />
                      @if (l.terminationReason) { <div class="cell-sub" [title]="l.terminationReason">{{ l.terminationReason }}</div> }
                    </td>
                    <td class="num">
                      <button class="btn sm ghost" title="Lease history for this unit" (click)="history(l)"><app-icon name="calendar" [size]="14" /></button>
                      @if (auth.canWrite() && (l.status === 'Active' || l.status === 'PendingRenewal')) {
                        <button class="btn sm" (click)="act(l, 'renew')">Renew</button>
                        <button class="btn sm" (click)="act(l, 'terminate')">Terminate</button>
                      }
                    </td>
                  </tr>
                } @empty { <tr><td colspan="8" class="empty">No leases found.</td></tr> }
              }
            </tbody>
          </table>
        </div>
        <app-pagination [page]="page()" [pageSize]="pageSize" [total]="total()" (pageChange)="goTo($event)" />
      </div>
    </div>

    @if (createOpen()) { <app-lease-form (closed)="createOpen.set(false)" (saved)="createOpen.set(false); load()" /> }
    @if (action(); as a) { <app-lease-action [lease]="a.lease" [mode]="a.mode" (closed)="action.set(null)" (saved)="action.set(null); load()" /> }
  `,
})
export class LeasesPageComponent implements OnInit {
  private svc = inject(LeasesService);
  private fb = inject(FormBuilder).nonNullable;
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  auth = inject(AuthService);

  statuses = LEASE_STATUSES;
  label = label;
  pageSize = 10;
  rows = signal<Lease[]>([]);
  total = signal(0);
  page = signal(1);
  loading = signal(true);
  createOpen = signal(false);
  action = signal<{ lease: Lease; mode: 'renew' | 'terminate' } | null>(null);
  filters = this.fb.group({ status: [''] });

  unitFilter: string | null = null;
  tenantFilter: string | null = null;

  ngOnInit() {
    this.route.queryParamMap.subscribe((q) => {
      this.unitFilter = q.get('unitId');
      this.tenantFilter = q.get('tenantId');
      this.page.set(1);
      this.load();
    });
    this.filters.valueChanges.subscribe(() => { this.page.set(1); this.load(); });
  }

  soon(end: string) { const d = daysUntil(end); return d !== null && d >= 0 && d <= 30; }

  load() {
    this.loading.set(true);
    this.svc.list({ ...this.filters.getRawValue(), unitId: this.unitFilter, tenantId: this.tenantFilter, page: this.page(), pageSize: this.pageSize }).subscribe({
      next: (r) => { this.rows.set(r.items); this.total.set(r.totalCount); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
  goTo(p: number) { this.page.set(p); this.load(); }
  act(lease: Lease, mode: 'renew' | 'terminate') { this.action.set({ lease, mode }); }
  history(l: Lease) { this.router.navigate(['/leases'], { queryParams: { unitId: l.unitId } }); }
  clearHistory() { this.router.navigate(['/leases']); }
}
