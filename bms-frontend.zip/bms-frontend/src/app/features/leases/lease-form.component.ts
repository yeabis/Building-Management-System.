import { Component, EventEmitter, OnInit, Output, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Tenant, Unit } from '../../core/models/models';
import { LeasesService, TenantsService, UnitsService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { endAfterStart, plusMonths, today } from '../../core/utils';
import { FieldErrorComponent, ModalComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-lease-form',
  standalone: true,
  imports: [ReactiveFormsModule, ModalComponent, FieldErrorComponent],
  template: `
    <app-modal title="Create lease agreement" [width]="640" (closed)="closed.emit()">
      <form [formGroup]="form" (ngSubmit)="submit()" novalidate>
        <div class="form-grid">
          <div class="field">
            <label for="tn">Tenant</label>
            <select id="tn" class="input" formControlName="tenantId">
              <option [ngValue]="null" disabled>Select tenant…</option>
              @for (t of tenants(); track t.id) { <option [ngValue]="t.id">{{ t.organizationName }}</option> }
            </select>
            <app-field-error [control]="form.controls.tenantId" />
          </div>
          <div class="field">
            <label for="un">Available unit</label>
            <select id="un" class="input" formControlName="unitId" (change)="onUnit()">
              <option [ngValue]="null" disabled>Select unit…</option>
              @for (u of units(); track u.id) { <option [ngValue]="u.id">{{ u.unitNumber }} · Floor {{ u.floorNumber }} · {{ u.unitType }}</option> }
            </select>
            <app-field-error [control]="form.controls.unitId" />
            @if (!loading() && units().length === 0) { <small class="err">No units are currently available.</small> }
          </div>
          <div class="field">
            <label for="sd">Start date</label>
            <input id="sd" class="input" type="date" formControlName="startDate" />
            <app-field-error [control]="form.controls.startDate" />
          </div>
          <div class="field">
            <label for="ed">End date</label>
            <input id="ed" class="input" type="date" formControlName="endDate" />
            <app-field-error [control]="form.controls.endDate" />
          </div>
          @if (form.errors?.['endBeforeStart'] && form.controls.endDate.touched) {
            <div class="field full"><small class="err">End date must be after the start date.</small></div>
          }
          <div class="field">
            <label for="mr">Monthly rent (ETB)</label>
            <input id="mr" class="input" type="number" formControlName="monthlyRent" />
            <app-field-error [control]="form.controls.monthlyRent" />
          </div>
          <div class="field">
            <label for="dp">Deposit (ETB)</label>
            <input id="dp" class="input" type="number" formControlName="depositAmount" />
            <app-field-error [control]="form.controls.depositAmount" />
          </div>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn" (click)="closed.emit()">Cancel</button>
          <button type="submit" class="btn primary" [disabled]="saving()">
            @if (saving()) { <span class="spinner"></span> } Create lease
          </button>
        </div>
      </form>
    </app-modal>
  `,
})
export class LeaseFormComponent implements OnInit {
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  private fb = inject(FormBuilder);
  private leases = inject(LeasesService);
  private tenantsSvc = inject(TenantsService);
  private unitsSvc = inject(UnitsService);
  private toast = inject(ToastService);

  tenants = signal<Tenant[]>([]);
  units = signal<Unit[]>([]);
  loading = signal(true);
  saving = signal(false);

  form = this.fb.group(
    {
      tenantId: this.fb.control<number | null>(null, Validators.required),
      unitId: this.fb.control<number | null>(null, Validators.required),
      startDate: [today(), Validators.required],
      endDate: [plusMonths(today(), 12), Validators.required],
      monthlyRent: [0, [Validators.required, Validators.min(1)]],
      depositAmount: [0, [Validators.required, Validators.min(0)]],
    },
    { validators: endAfterStart },
  );

  ngOnInit() {
    this.tenantsSvc.list({ isActive: true, page: 1, pageSize: 200 }).subscribe((r) => this.tenants.set(r.items));
    this.unitsSvc.list({ status: 'Available', page: 1, pageSize: 200 }).subscribe((r) => { this.units.set(r.items); this.loading.set(false); });
  }

  /** Pre-fill rent (and a 3-month deposit) from the chosen unit. */
  onUnit() {
    const u = this.units().find((x) => x.id === this.form.controls.unitId.value);
    if (u) this.form.patchValue({ monthlyRent: u.monthlyRent, depositAmount: u.monthlyRent * 3 });
  }

  submit() {
    this.form.markAllAsTouched();
    if (this.form.invalid || this.saving()) return;
    this.saving.set(true);
    const v = this.form.getRawValue();
    this.leases.create({ ...v, tenantId: v.tenantId!, unitId: v.unitId!, monthlyRent: v.monthlyRent!, depositAmount: v.depositAmount!, startDate: v.startDate!, endDate: v.endDate! }).subscribe({
      next: () => { this.toast.success('Lease created — unit marked as Occupied'); this.saved.emit(); },
      error: () => this.saving.set(false),
    });
  }
}
