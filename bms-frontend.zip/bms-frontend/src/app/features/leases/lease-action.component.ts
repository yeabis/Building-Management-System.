import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Lease } from '../../core/models/models';
import { LeasesService } from '../../core/services/feature-services';
import { ToastService } from '../../core/services/toast.service';
import { plusMonths } from '../../core/utils';
import { FieldErrorComponent, ModalComponent } from '../../shared/ui.components';

@Component({
  selector: 'app-lease-action',
  standalone: true,
  imports: [ReactiveFormsModule, ModalComponent, FieldErrorComponent],
  template: `
    <app-modal [title]="(mode === 'renew' ? 'Renew lease · ' : 'Terminate lease · ') + lease.unitNumber" (closed)="closed.emit()">
      <p class="muted" style="margin-top:0">{{ lease.tenantName }} · current term ends {{ lease.endDate }}</p>

      @if (mode === 'renew') {
        <form [formGroup]="renewForm" (ngSubmit)="renew()" novalidate>
          <div class="form-grid">
            <div class="field">
              <label for="ne">New end date</label>
              <input id="ne" class="input" type="date" formControlName="newEndDate" />
              <app-field-error [control]="renewForm.controls.newEndDate" />
              @if (renewForm.controls.newEndDate.value && renewForm.controls.newEndDate.value <= lease.endDate) {
                <small class="err">Must be after the current end date.</small>
              }
            </div>
            <div class="field">
              <label for="nr">New monthly rent (ETB)</label>
              <input id="nr" class="input" type="number" formControlName="newMonthlyRent" />
              <app-field-error [control]="renewForm.controls.newMonthlyRent" />
            </div>
          </div>
          <div class="modal-actions">
            <button type="button" class="btn" (click)="closed.emit()">Cancel</button>
            <button type="submit" class="btn primary" [disabled]="saving()">@if (saving()) { <span class="spinner"></span> } Renew lease</button>
          </div>
        </form>
      } @else {
        <form [formGroup]="termForm" (ngSubmit)="terminate()" novalidate>
          <div class="form-error">Terminating ends the lease early and marks the unit Available.</div>
          <div class="field">
            <label for="rs">Reason for termination</label>
            <textarea id="rs" class="input" formControlName="reason"></textarea>
            <app-field-error [control]="termForm.controls.reason" />
          </div>
          <div class="modal-actions">
            <button type="button" class="btn" (click)="closed.emit()">Cancel</button>
            <button type="submit" class="btn danger" [disabled]="saving()">@if (saving()) { <span class="spinner"></span> } Terminate lease</button>
          </div>
        </form>
      }
    </app-modal>
  `,
})
export class LeaseActionComponent implements OnInit {
  @Input({ required: true }) lease!: Lease;
  @Input({ required: true }) mode!: 'renew' | 'terminate';
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  private fb = inject(FormBuilder).nonNullable;
  private svc = inject(LeasesService);
  private toast = inject(ToastService);
  saving = signal(false);

  renewForm = this.fb.group({ newEndDate: ['', Validators.required], newMonthlyRent: [0, [Validators.required, Validators.min(1)]] });
  termForm = this.fb.group({ reason: ['', [Validators.required, Validators.minLength(5)]] });

  ngOnInit() {
    this.renewForm.patchValue({ newEndDate: plusMonths(this.lease.endDate, 12), newMonthlyRent: this.lease.monthlyRent });
  }

  renew() {
    this.renewForm.markAllAsTouched();
    const v = this.renewForm.getRawValue();
    if (this.renewForm.invalid || v.newEndDate <= this.lease.endDate || this.saving()) return;
    this.saving.set(true);
    this.svc.renew(this.lease.id, v).subscribe({
      next: () => { this.toast.success('Lease renewed'); this.saved.emit(); },
      error: () => this.saving.set(false),
    });
  }

  terminate() {
    this.termForm.markAllAsTouched();
    if (this.termForm.invalid || this.saving()) return;
    this.saving.set(true);
    this.svc.terminate(this.lease.id, this.termForm.getRawValue()).subscribe({
      next: () => { this.toast.success('Lease terminated — unit is now Available'); this.saved.emit(); },
      error: () => this.saving.set(false),
    });
  }
}
