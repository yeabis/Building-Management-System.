import { Routes } from '@angular/router';
import { authGuard, guestGuard } from './core/guards/guards';

export const routes: Routes = [
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./features/auth/login.component').then((m) => m.LoginComponent),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/shell.component').then((m) => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', loadComponent: () => import('./features/dashboard/dashboard.component').then((m) => m.DashboardComponent) },
      { path: 'units', loadComponent: () => import('./features/units/units-page.component').then((m) => m.UnitsPageComponent) },
      { path: 'tenants', loadComponent: () => import('./features/tenants/tenants-list.component').then((m) => m.TenantsListComponent) },
      { path: 'tenants/:id', loadComponent: () => import('./features/tenants/tenant-profile.component').then((m) => m.TenantProfileComponent) },
      { path: 'leases', loadComponent: () => import('./features/leases/leases-page.component').then((m) => m.LeasesPageComponent) },
      { path: 'payments', loadComponent: () => import('./features/payments/payments-page.component').then((m) => m.PaymentsPageComponent) },
      { path: 'reports', loadComponent: () => import('./features/reports/reports-page.component').then((m) => m.ReportsPageComponent) },
      { path: 'notifications', loadComponent: () => import('./features/notifications/notifications-page.component').then((m) => m.NotificationsPageComponent) },
    ],
  },
  { path: '**', redirectTo: '' },
];
