export const environment = {
  production: false,
  /** Base URL of the ASP.NET Core API (BMS.API). */
  apiUrl: 'https://localhost:5001/api',
  /**
   * true  -> an in-memory mock backend answers every /api call (no server needed).
   * false -> requests go to apiUrl.
   */
  useMock: true,
};
